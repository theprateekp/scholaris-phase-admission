# Data Schema
## Scholaris — Admission Module (Phase 1)

Expands PRD §12's high-level data model into a concrete, implementable schema (Prisma-style, maps directly to PostgreSQL). Field lists are pulled from PRD §6 (form-by-form spec) and §7 (shared-field map) to guarantee 100% field fidelity (Goal G1).

---

## 1. Entity Overview

```
AdmissionRecord (1) ──< DocumentUpload (many)
AdmissionRecord (1) ── StudentProfile (1)
AdmissionRecord (1) ── Form1Application (1)
AdmissionRecord (1) ── Form2DocumentChecklist (1) ──< ChecklistItem (18)
AdmissionRecord (1) ── Form3Eligibility (1)
AdmissionRecord (1) ── Form4AntiRaggingAffidavit (1)
AdmissionRecord (1) ── Form5LibraryMembership (1)
AdmissionRecord (1) ── FeeRecord (1) ──< Installment (many)
AdmissionRecord (1) ──< PrintLog (many)
AdmissionRecord (1) ──< VerificationLog (many)
AdmissionRecord (1) ── AdmittedStudent (0..1, populated only on ADMITTED)
```

---

## 2. Core Tables

### 2.1 `AdmissionRecord`

| Column | Type | Notes |
|---|---|---|
| id | uuid, PK | |
| status | enum `AdmissionStatus` | See §3 |
| institution_id | uuid, FK → `Institution` | Multi-tenancy readiness (§13 PRD); hardcoded to one row in v1 |
| assigned_operator_id | uuid, FK → `User`, nullable | Supports future "assign to" per-stage hand-off (PRD open question §14.4) |
| created_at | timestamptz | |
| updated_at | timestamptz | |
| locked_at | timestamptz, nullable | Set when status = `ADMITTED`; blocks further writes at the application layer |
| hold_reason | text, nullable | Populated if status = `ON_HOLD` |
| rejected_reason | text, nullable | Populated if status = `REJECTED` |

### 2.2 `StudentProfile` (canonical shared fields — PRD §7)

One row per `AdmissionRecord`. This is the **single source of truth** for auto-fetch propagation; each field also records `source_form` (which form first captured it) for the "auto-filled" indicator logic.

| Column | Type | Notes |
|---|---|---|
| admission_record_id | uuid, PK/FK | |
| full_name_surname | text | |
| full_name_first | text | |
| full_name_father | text | |
| father_name | text | |
| mother_name | text | |
| date_of_birth | date | |
| gender | enum (`Male`,`Female`,`Transgender`) | Form 3 allows Transgender; Forms 1/5 use Male/Female only — app layer restricts options per form while storing the canonical value here |
| blood_group | text | |
| mobile_no | text (encrypted-at-rest not required, but validated format) | |
| parents_tel_no | text | Library form (Form 5) specific but stored canonically |
| email | text | |
| religion_caste | text | Free text, Form 1 |
| category | text | Reservation category (Open/OBC/SBC/NT1-3/SC/ST/DEF/PH etc. — union of all forms' category vocab, see Rules doc) |
| branch_course | text | |
| admission_year_start | int | |
| admission_year_end | int | |
| correspondence_address | text | |
| correspondence_pin | text | |
| permanent_address | text | |
| permanent_pin | text | |
| aadhar_no | text, **encrypted** | Sensitive PII (PRD §14.6) |
| pan_no | text | |
| photo_file_ref | text (S3 key), nullable | Reused across Form 1 photo box and Form 5 |
| admission_receipt_no | text, nullable | |
| updated_at | timestamptz | |

### 2.3 `Form1Application`

| Column | Type |
|---|---|
| admission_record_id | uuid, PK/FK |
| admission_quota | enum (`CAP_CET_AIEEE`,`JK`,`MGMT`,`AGAINST_CAP`) |
| admission_category | text |
| home_university | text |
| mother_tongue | text |
| ssc_marks_english_obtained / _out_of | numeric |
| ssc_marks_maths_obtained / _out_of | numeric |
| ssc_grand_total_obtained / _out_of | numeric |
| ssc_percentage | numeric |
| ssc_year_of_passing | int |
| hsc_physics_obtained / _out_of | numeric |
| hsc_chemistry_obtained / _out_of | numeric |
| hsc_maths_obtained / _out_of | numeric |
| hsc_pcm_total_obtained / _out_of | numeric |
| hsc_grand_total_obtained / _out_of | numeric |
| hsc_year_of_passing | int |
| cet_physics_obtained / _out_of | numeric |
| cet_chemistry_obtained / _out_of | numeric |
| cet_maths_obtained / _out_of | numeric |
| cet_pcm_total_obtained / _out_of | numeric |
| cet_exam_seat_no | text |
| cet_merit_no | text |
| aieee_marks | text |
| diploma_marks_obtained / _out_of | numeric, nullable |
| diploma_branch_course | text, nullable |
| diploma_bte_enrollment_no | text, nullable |
| diploma_year_of_passing | int, nullable |
| annual_income_of_parent | numeric |
| date_field | date |
| place_field | text |
| signature_student_ref | text, nullable | Left blank in v1 (wet-ink assumption, PRD §14.1) |
| signature_parent_ref | text, nullable | |
| office_use_eligible_for | text, nullable | Admin-entered, "For Office Use Only" block |
| office_use_branch | enum (`Civil`,`Comp`,`ETC`,`IT`,`Mech`,`Elect`), nullable | |

### 2.4 `Form2DocumentChecklist` + `ChecklistItem`

`Form2DocumentChecklist`: admission_record_id (PK/FK), admission_type (`FE`/`DSE`), cap_id, staff_sign_ref, student_sign_ref, checklist_date.

`ChecklistItem` (18 rows per record, seeded from a static reference list):

| Column | Type |
|---|---|
| id | uuid, PK |
| form2_id | uuid, FK |
| sr_no | int (1–18) |
| document_name | text | Allotment Letter, Confirmation Letter, S.S.C. Mark sheet, ... Passport Size 2 Photo (full list in Rules doc §2) |
| required | boolean | ticked Yes/No — drives Stage 2 upload slot generation |

### 2.5 `Form3Eligibility`

| Column | Type |
|---|---|
| admission_record_id | uuid, PK/FK |
| course_name | text |
| course_year | enum (`1st`,`2nd`,`3rd`,`4th`,`5th`) |
| applicant_type | enum (`Maharashtrian`,`Non-Maharashtrian`) |
| nationality | text |
| religion | text |
| category_tick | enum (`Open`,`SC`,`ST`,`DT_A`,`NT_B`,`NT_C`,`NT_D`,`OBC`,`SBC`,`SEBC`,`EWS`) |
| belongs_to_reserved_yn | boolean |
| physically_disabled_yn | boolean |
| physically_disabled_type | enum (`P1`,`P2`,`P3`,`P4`,`OT`), nullable |
| qual_course_name / duration / university / college_dept | text |
| qual_seat_no / month_year_passing / percentage / class_grade | text/numeric |
| gap_last_exam_name / seat_no / month_year_passing / percentage / class_grade | text/numeric, nullable (repeatable if multiple gap years — model as child table `EducationalGap` if >1 needed) |
| minority_yn | boolean |
| minority_linguistic | boolean |
| minority_religion | boolean |
| signature_candidate_ref | text, nullable |
| office_receipt_no / date / eligible_status / asst / sr_asst / os_registrar_hod | text | Office-use block |

### 2.6 `Form4AntiRaggingAffidavit`

| Column | Type |
|---|---|
| admission_record_id | uuid, PK/FK |
| full_name_with_enrollment_no | text |
| son_daughter_of | text |
| admitted_to_institution | text | Auto-fills from Institution name |
| declared_day / month / year | text |
| signature_deponent_ref | text, nullable |
| verified_at_place | text |
| verified_day / month / year | text |
| signature_deponent_verification_ref | text, nullable |

> Oath Commissioner section intentionally has **no digital fields** — confirmed out of scope (PRD §14.2), exists only in the print template as static blank space.

### 2.7 `Form5LibraryMembership`

| Column | Type |
|---|---|
| admission_record_id | uuid, PK/FK |
| year_level | enum (`FE`,`SE`,`ME`,`PhD`) |
| diploma_fy_dsy | enum (`FY`,`DSY`), nullable |
| local_address | text |
| local_city | text |
| local_pin | text |
| cast_category | enum (`Open`,`SC`,`ST`,`VJ`,`NT1`,`NT2`,`NT3`,`SBC`,`Other`) |
| library_signature_ref | text, nullable |
| library_membership_id_card_no | text, nullable | Library-use-only |
| remark | text, nullable | Library-use-only |
| librarian_sign_ref | text, nullable | Library-use-only |
| rules_agreed_yn | boolean | Backing the mandatory "I have read and agree" checkbox (PRD §6.5) |
| rules_agreed_at | timestamptz, nullable |

### 2.8 `DocumentUpload`

| Column | Type |
|---|---|
| id | uuid, PK |
| admission_record_id | uuid, FK |
| checklist_item_id | uuid, FK → `ChecklistItem` |
| file_ref | text (S3 key) |
| file_type | enum (`image`,`pdf`) |
| upload_method | enum (`scan`,`drag_drop`,`browse`) |
| status | enum (`NOT_UPLOADED`,`UPLOADED_PENDING_REVIEW`,`VERIFIED`,`REJECTED_REUPLOAD`) |
| system_check_passed | boolean, nullable | Auto-check result |
| system_check_notes | text, nullable | |
| received_yn | boolean, nullable | Admin manual tick |
| verified_by | uuid, FK → `User`, nullable | |
| verified_at | timestamptz, nullable | |
| uploaded_at | timestamptz | |

### 2.9 `FeeRecord` + `Installment`

`FeeRecord`: admission_record_id (PK/FK), total_fee_amount, amount_paid, remaining_balance (computed), mode_of_payment (enum `Cash`,`UPI`,`Bank_to_Bank`,`RTGS`,`DD`), installment_enabled (boolean), fee_status (enum `Unpaid`,`Partially_Paid`,`Fully_Paid` — computed).

`Installment`: id (PK), fee_record_id (FK), installment_no (int, auto-increment per record), amount, mode_of_payment, date, remaining_after.

### 2.10 `PrintLog`

id, admission_record_id (FK), printed_at, printed_by (FK → User), version (int, increments per print event).

### 2.11 `VerificationLog` (append-only audit trail)

| Column | Type |
|---|---|
| id | uuid, PK |
| admission_record_id | uuid, FK |
| action | enum (`FORMS_SAVE_PASSWORD`,`DOC_VERIFIED`,`FINAL_VERIFICATION_PASSWORD`,`STATUS_CHANGE`,`UNLOCK`) |
| actor_id | uuid, FK → `User` |
| role_at_time | text | Snapshot of role, since roles may change later |
| password_confirmed | boolean | |
| timestamp | timestamptz | |
| notes | text, nullable |

### 2.12 `AdmittedStudent`

Immutable snapshot table, populated once on transition to `ADMITTED`. Structurally a denormalized copy of `StudentProfile` + all 5 form tables + fee summary + document verification summary, so downstream modules (ID cards, attendance, academic records — PRD §16) never need to join back through the in-flight admission pipeline tables.

### 2.13 Supporting Tables

- `Institution` — id, name, address, phone, website, crest_asset_ref (multi-tenancy anchor, §13).
- `User` — id, name, email, password_hash, role (enum `FrontDesk`,`VerificationAdmin`,`HigherAuthority`,`SystemAdmin` — for future role-based views per PRD §3 note).

---

## 3. `AdmissionStatus` Enum (PRD §5)

```
DRAFT
FORMS_COMPLETE
DOCS_IN_PROGRESS
DOCS_VERIFIED
FEE_RECORDED
READY_TO_PRINT
PRINTED
PENDING_FINAL_VERIFICATION
ADMITTED
ON_HOLD        -- recommended addition, PRD §14.3
REJECTED       -- recommended addition, PRD §14.3
```

---

## 4. Encryption & Sensitive Fields Note

Per PRD §14.6, `aadhar_no` (Form 3) and any APAAR/ABC ID reference (Form 2 checklist doc) require encryption-at-rest and access logging. Recommended: application-level AES-256 field encryption with key management via the hosting platform's KMS, plus a `SensitiveFieldAccessLog` table if/when direct value display (not just masked) is needed by an admin.
