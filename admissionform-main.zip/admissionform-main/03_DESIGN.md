# Design Specification
## Scholaris — Admin Dashboard (Phase 1 Deliverable)

Source: PRD §11 ("warm, calm, professional"). This document turns that direction into concrete, buildable tokens and screen-level guidance.

---

## 1. Design Principles

1. **Institutional warmth, not SaaS-default coldness.** This is a college admissions office, not a startup analytics tool — avoid the generic "blue gradient dashboard" look entirely.
2. **One primary action per screen state.** Front-desk staff should never wonder what to click next; secondary actions are visually quieter.
3. **Calm urgency.** Status colors inform without alarming — no neon red, no aggressive pulsing badges.
4. **Legibility over decoration.** Long forms with dense fields (SSC/HSC/CET mark tables) need generous whitespace and clear grouping more than visual flourish.
5. **Print fidelity is part of the design system**, not a separate concern — the preview/print template's typography and spacing rules are documented alongside the app UI rules (§6).

---

## 2. Color Tokens

| Token | Value (suggested) | Usage |
|---|---|---|
| `--color-bg` | `#FBF8F3` (soft ivory/warm-white) | App background |
| `--color-surface` | `#FFFFFF` | Cards, panels, modals |
| `--color-surface-muted` | `#F3EEE5` | Secondary panels, table zebra striping |
| `--color-accent` | `#B5622F` (muted terracotta) *or* `#0F5C56` (deep teal) — pick one, do not mix | Primary buttons, active stepper state, links |
| `--color-accent-hover` | 10% darker than accent | Hover/active states |
| `--color-text-primary` | `#2B2620` (warm near-black) | Body text, headings |
| `--color-text-secondary` | `#6B6255` | Helper text, field labels |
| `--color-border` | `#E4DCCB` | Card borders, table gridlines |
| `--color-success` (verified/complete) | `#7A9471` (muted sage green) | Verified docs, completed stages |
| `--color-pending` (pending) | `#C99A3D` (warm amber) | Pending review, awaiting action |
| `--color-blocked` (blocked/rejected) | `#B96A56` (soft clay/red) | Rejected docs, `ON_HOLD`/`REJECTED` status |
| `--color-focus-ring` | Accent at 40% opacity | Keyboard focus indicator (accessibility) |

**Rule:** never introduce a second saturated accent color. All status meaning is carried by the 3 muted status colors above, not by additional hues.

---

## 3. Typography

| Role | Font | Notes |
|---|---|---|
| Headings (H1–H3, dashboard section titles) | A humanist serif or well-spaced humanist sans (e.g., **Source Serif 4** or **Fraunces** for serif; **Inter** or **General Sans** for humanist sans) | Institutional, not playful. Pick serif if the college identity leans traditional; sans if it should feel modern-but-calm. |
| Body / data / tables | **Inter** or **IBM Plex Sans** | High legibility at small sizes for dense mark-sheet tables. |
| Print template | **Match the original stationery as closely as licensing allows** — typically a standard serif (Times New Roman-adjacent) for legal/affidavit text, matching the source PDFs' look | Print fidelity (§10 of PRD) overrides app-UI typography choices on the print template specifically. |

**Scale:** 
- H1 28px/1.3, H2 22px/1.35, H3 18px/1.4, Body 15px/1.6, Small/helper 13px/1.5.

---

## 4. Spacing & Shape

- Base spacing unit: **4px**, scale: 4/8/12/16/24/32/48/64.
- Corner radius: **6px** for inputs/buttons, **10px** for cards — "rounded-but-restrained," explicitly avoiding the 16px+ bubbly radius common in playful consumer apps.
- Shadows: soft, single-layer (`0 1px 3px rgba(43,38,32,0.08)`) — no heavy drop shadows.
- Card padding: 24px desktop, 16px tablet.

---

## 5. Core Components

| Component | Notes |
|---|---|
| **Stepper** (5-form wizard, 6-stage breadcrumb) | Persistent, always visible per §11.3 of PRD. Active step in accent color, completed steps in sage green with a checkmark, upcoming steps muted gray. |
| **Status badge** | Pill shape, uses the 3 status colors (§2) + neutral gray for `DRAFT`. Text label always included (never color-only, for accessibility). |
| **Review modal** (end-of-form) | Read-only summary in a clean two-column label/value layout; "Back to Edit" (secondary/ghost button) + "Confirm & Continue" (primary, accent-filled). |
| **Password gate modal** | Small, centered, single password field + primary "Confirm" button; error state shows inline red-clay text below the field, not a toast (keeps focus on the modal per §11.3's "keep flow calm and uninterrupted"). |
| **Document slot card** | Shows doc name, state badge (Not Uploaded/Pending/Verified/Rejected), thumbnail preview once uploaded, and the two distinct actions (Preview, Verified) as separate buttons — never merged, since PRD explicitly treats upload and verification as separate actions (§8). |
| **Fee summary card** | Total/Paid/Remaining in a 3-column stat row, installment table below if enabled, fee status badge in the corner. |
| **Pipeline table/kanban toggle** | Table view: sortable columns (Name, Branch, Category, Status, Fee Status, Last Updated). Kanban view: one column per status, card per student. |
| **Preview/print viewport** | White "paper" surface on the warm-ivory background (visually distinct — this is the one place true white is intentional, to simulate physical paper), A4 aspect ratio, scroll-snap between the 5 forms. |

---

## 6. Print Template Design Rules (distinct from app UI)

- Print templates use **pure white background**, **black text**, standard A4 margins matching the original scans (approx. 1" top/bottom, 0.75" sides, adjust per physical validation).
- Checkbox glyphs rendered as bordered squares (`☐`) with a filled/checked state (`☑`) — must match the tick style used in the original forms (`✓`/`X` in Form 2's checklist, per the source PDF).
- Table borders: 1px solid black, matching the source forms' grid style exactly — no rounded corners, no shadows, no accent colors in print output.
- Static legal text (Anti-Ragging clauses, Library Rules & Regulations, Annexure 'A' fee table) reproduced verbatim, same numbering, same paragraph breaks as the original PDFs.
- Signature lines rendered as blank underlines (per PRD's assumption that signatures stay wet-ink, §14.1) — never pre-filled, even if a digital signature capture is added later.

---

## 7. Accessibility

- All interactive elements keyboard-navigable; visible focus ring (`--color-focus-ring`).
- Status never conveyed by color alone — always paired with text/label or icon.
- Minimum tap target 44×44px on the Document Verification Workspace (tablet scanning stations, per §13 of PRD).
- Form field errors announced via `aria-live` region, not just color change.

---

## 8. Screen Inventory (maps 1:1 to PRD §11.2)

1. Overview / Home
2. Student Pipeline List (table + kanban toggle)
3. New Admission → 5-Form Wizard
4. Document Verification Workspace
5. Fee Entry Screen
6. Preview & Print Screen
7. Final Verification Queue
8. Admitted Students Registry
