# Product Requirements Document
## Scholaris — Digital Admission Form Module

| | |
|---|---|
| **Product** | Scholaris (Multi-tenant College Management SaaS) |
| **Module** | Admission Form Digitization & Admin Dashboard |
| **Document Owner** | Aditya |
| **Institution (pilot tenant)** | TSSM's Bhivarabai Sawant College of Engineering & Research, Narhe, Pune |
| **Version** | 1.0 |
| **Status** | Draft for build — Phase 1 (Admin Dashboard) |
| **Date** | July 2026 |

---

## 1. Purpose & Problem Statement

Bhivarabai Sawant College currently runs its admission intake entirely on paper. A candidate physically fills five separate forms — **Application Form, List of Documents, Application for Eligibility (SPPU), Anti-Ragging Affidavit (Annexure I), and Library Membership Form** — each with its own layout, overlapping fields, and manual cross-checking. This causes:

1. **Redundant data entry** — the same name, DOB, address, and category are handwritten up to 5 times, increasing transcription errors.
2. **No single source of truth** — marks, documents, and fee status live in separate physical folders.
3. **Slow, error-prone verification** — document checklists and eligibility checks are manual and easy to miss.
4. **No audit trail** — nothing digitally proves who verified what, and when.
5. **Print inconsistency** — final submitted forms must still match the university/college's exact prescribed layout.

**Scholaris' Admission Form module digitizes this entire pipeline** while preserving the exact prescribed structure of every form, so the printed output is indistinguishable from — and legally equivalent to — the original stationery.

---

## 2. Goals

| Goal | Description |
|---|---|
| G1 | Digitize all 5 admission forms with 100% field and layout fidelity |
| G2 | Auto-populate shared fields across forms once entered anywhere (single entry, multi-form fill) |
| G3 | Digitize document checklist + upload + dual verification (auto + admin) |
| G4 | Track fee payment status per student, including installments |
| G5 | Generate a pixel-accurate, print-ready PDF of all 5 forms for blank-paper printing |
| G6 | Support a second, independent "higher authority" verification pass before final admission |
| G7 | Persist a clean, structured student record to the final admitted-students database |
| G8 | Ship a warm, calm, professional Admin Dashboard as the first deliverable |

### Non-Goals (this phase)
- Student self-service portal (student does not fill their own form in v1 — admin/front-desk operator does, seated with the candidate)
- Online fee payment gateway integration (only fee *status* is recorded in v1)
- Mobile app
- Multi-tenant configuration UI (hardcoded to this college's templates for v1; architecture should stay tenant-ready)

---

## 3. Users & Personas

| Role | Description | Primary Actions |
|---|---|---|
| **Front Desk / Data Entry Admin** | Fills the 5 forms with/for the candidate during admission | Form fill, document upload, fee entry |
| **Verification Admin** | Checks uploaded documents against the checklist | Document verify, tick/cross checklist |
| **Higher Authority (Principal/Registrar/HOD-level)** | Final gatekeeper who checks printed + digital form together | Final verification, password-gated approval |
| **System Admin** | Manages users, passwords, and oversees the pipeline | User management, monitoring, reports |

> **Phase 1 build scope:** one unified **Admin Dashboard** used by all the above roles (role-based views can be layered later); password gates are used at two checkpoints (post-5-forms save, and final higher-authority verification) rather than full role-based auth, per your workflow description.

---

## 4. End-to-End Workflow

```
┌─────────────────┐   ┌──────────────────┐   ┌───────────────┐   ┌──────────────┐   ┌───────────────────┐   ┌──────────────────┐
│ 1. Fill 5 Forms  │──▶│ 2. Upload &      │──▶│ 3. Fee Status │──▶│ 4. Preview & │──▶│ 5. Higher Authority│──▶│ 6. Final Database │
│   Digitally      │   │  Verify Documents│   │   Entry       │   │  Print Forms │   │  Verification      │   │   (Admitted)      │
└─────────────────┘   └──────────────────┘   └───────────────┘   └──────────────┘   └───────────────────┘   └──────────────────┘
```

Each stage gates the next. A student record carries a **status field** that moves through:

`DRAFT → FORMS_COMPLETE → DOCS_PENDING → DOCS_VERIFIED → FEE_RECORDED → READY_TO_PRINT → PRINTED → PENDING_FINAL_VERIFICATION → ADMITTED`

---

### 4.1 Stage 1 — Digital Form Filling

- Candidate/operator fills **5 forms in sequence** inside one guided flow (stepper UI: Form 1 of 5 → 5 of 5).
- Each form strictly mirrors its physical layout — same sections, same order, same tables — nothing added or removed (see §6 for exact field specs pulled from the source PDFs).
- **Auto-fetch / shared-field propagation:** the moment a shared field (e.g., Student Name, DOB, Mobile No, Category) is filled in any form, it silently pre-fills the same field on every other form where it appears — the operator can still override per-form if a form legitimately needs a variant (e.g., "Name in CAPITAL" formatting for the Library form). See §7 for the full field-mapping table.
- **Per-form review popup:** at the end of each of the 5 forms, a "Review this form" modal shows a clean summary before allowing "Confirm & Continue."
- **Completion gate:** after form 5's review is confirmed, the system prompts for the **Admin Password**. On correct entry, the full 5-form dataset is saved as a single Admission Record and the flow advances to Stage 2. Incorrect password blocks the save (with retry, not silent failure).

### 4.2 Stage 2 — Document Upload & Verification

- Landing point: the **List of Documents** checklist that was ticked in Form 2 during Stage 1 becomes the live task list here (only documents marked "required" appear as upload slots — items marked N/A stay hidden/disabled).
- Two intake methods per document:
  1. **Scan** (device camera / connected scanner capture)
  2. **Drag-and-drop or file upload** (image/PDF)
- Each uploaded document gets a **Preview** action (inline viewer) before verification.
- Admin reviews the preview, then:
  - Ticks the document as **Received: Yes**
  - Clicks **Verified** (this is a distinct action from "uploaded" — a doc can be uploaded but not yet verified)
- **Auto-verification pass:** basic automated checks run on upload (file present, readable, correct type, non-blank page, matches expected document class if OCR/heuristics are enabled later) and flag obvious issues before the admin's manual check — described as a two-layer check: system pass + admin pass.
- Stage only completes when every *required* document (per the ticked checklist) shows both "Received: Yes" and "Verified."

### 4.3 Stage 3 — Fee Payment Status

- Admin enters:
  - Total academic fee amount
  - Amount paid
  - Remaining balance (auto-calculated)
  - **Mode of payment:** Cash / UPI / Bank to Bank / RTGS / DD
  - **Installment toggle:** if ON, show a repeatable installment table — Installment #, Amount, Mode, Date, Remaining After This Installment
- This is a **status tracker**, not a payment gateway — no money moves through Scholaris in this phase.

### 4.4 Stage 4 — Preview & Print

- Full **Preview** view renders all 5 forms exactly as they will print — same margins, tables, checkboxes, and static legal/regulatory text (e.g., the Anti-Ragging affidavit clauses, Library Rules & Regulations) reproduced verbatim from the originals, with only the blank/underline fields populated with the candidate's data.
- Since forms print on **blank paper** (not pre-printed stationery), the system is the single source of the entire visual template — headers, college crest placement, table borders, signature lines, and the office-use-only sections must render at production quality.
- Admin can go back and edit any of the 5 forms from this preview before committing to print.
- **Print** action generates the final print job / downloadable PDF bundle (all 5 forms as one document, correctly paginated).

### 4.5 Stage 5 — Higher Authority Final Verification

- Student record moves to a **Pending Final Verification** queue.
- The higher authority reviews the **physical printed form** side-by-side with the **digital record** (the dashboard shows the same read-only preview used for printing).
- On confirming everything matches, they click **Verified**.
- System prompts for a **Verification Password**. Correct password → student status becomes `ADMITTED` and the record locks (no further edits without an explicit unlock/audit action).

### 4.6 Stage 6 — Final Database

- On admission, the complete structured record — all 5 forms' data, document metadata, fee status, and verification audit trail (who verified what, and when) — is written to the **Admitted Students** table, becoming the permanent institutional record and the source for future modules (ID cards, attendance, academic records, etc. — already part of the broader Scholaris platform Aditya is building).

---

## 5. Admission Record — Status Model

| Status | Meaning | Entered When |
|---|---|---|
| `DRAFT` | Forms started, not yet completed | Stage 1 begins |
| `FORMS_COMPLETE` | All 5 forms saved, admin password confirmed | End of Stage 1 |
| `DOCS_IN_PROGRESS` | Upload/verification underway | Start of Stage 2 |
| `DOCS_VERIFIED` | All required docs uploaded + verified | End of Stage 2 |
| `FEE_RECORDED` | Fee status entered | End of Stage 3 |
| `READY_TO_PRINT` | Preview approved | Start of Stage 4 |
| `PRINTED` | Physical copies generated | End of Stage 4 |
| `PENDING_FINAL_VERIFICATION` | Awaiting higher authority | Start of Stage 5 |
| `ADMITTED` | Fully verified, locked, in final DB | End of Stage 5 / Stage 6 |
| `REJECTED` / `ON_HOLD` | Exception paths (recommended addition — see §11) | Any stage |

---

## 6. Form-by-Form Field Specification

> Extracted directly from the 5 uploaded source documents. Field order, grouping, and static text below must be preserved exactly in the UI and the print template.

### 6.1 Form 1 — APPLICATION FORM (TSSM's Bhivrabai Sawant College)

**Header (non-editable branding):** College name, address, phone, website, crest, "APPLICATION FORM", Year field (20__–20__), photo box.

**Top selectors:**
- Branch/Course (text/dropdown)
- Admission Quota: `CAP(CET/AIEEE) / J&K / MGMT / AGAINST CAP`
- Admission Category: `Open / OBC / SBC / NT1 / NT2 / NT3 / SC / ST / DEF / PH`

**Fields:**
1. Name of Candidate — Surname / Name / Father's Name (block letters, 3 sub-fields)
2. Father's Name
3. Mother's Name
4. Date of Birth
5. Blood Group
6. Sex — Male / Female
7. Religion & Caste
8. Contact Tel. No. (with STD) + Mobile No.
9. Email Address
10. Mother Tongue
11. Home University
12. **S.S.C. Marks** — table: English / Mathematics / Grand Total / Percentage, rows: Obtained / Out of; + SSC Year of Passing
13. **H.S.C. Marks** — table: Physics / Chemistry / Mathematics / PCM Total / Grand Total, rows: Obtained / Out of; + HSC Year of Passing
14. **CET Marks** — table: Physics / Chemistry / Mathematics / PCM Total, rows: Obtained / Out of; + CET Exam Seat No. + Merit No.; + AIEEE Marks
15. **For Diploma Students** — Marks at Final Year (Obtained/Total); Branch/Course at Diploma; B.T.E. Enrollment No.; Diploma Year of Passing
16. Correspondence Address + Pin Code + Contact Tel. No. (STD) + Mobile No.
17. Permanent Address + Pin Code + Contact Tel. No. (STD) + Mobile No.
18. Annual Income of Parent (Rs.)
- Date, Place
- Signature of Parent/Guardian, Signature of Student (captured as uploaded signature image or left blank for wet-ink signing on the printed copy — see §11 open question)

**For Office Use Only (admin-entered, not candidate):**
- "Applicant Mr/Miss ___ is eligible for the First/Second Year Engineering course for academic year 20__-20__"
- Branch: `Civil / Comp / E&TC / IT / Mech / Elect`
- Principal (signature line)

### 6.2 Form 2 — LIST OF DOCUMENTS

**Header (non-editable branding):** Shetkari Shikshan Mandal / BSCOER letterhead.

**Candidate meta fields:**
- Name of Student
- Class
- Branch
- Admission Year
- Admission Type — `FE / DSE`
- Cap ID
- Student Mobile No.
- Email ID
- Admission Category

**Checklist table (Sr. No. 1–18), each row = Document Name + "Received Documents Yes or No (✓/X)" checkbox:**

| Sr. | Document |
|---|---|
| 1 | Allotment Letter |
| 2 | Confirmation Letter |
| 3 | S.S.C. Mark sheet |
| 4 | S.S.C. Board Certificate |
| 5 | H.S.C. Mark sheet |
| 6 | H.S.C. Board Certificate |
| 7 | Leaving / TC Certificate |
| 8 | Migration Certificate (If Applicable) |
| 9 | Age, Nationality, Domicile / Birth Certificate |
| 10 | Cast Certificate (If Applicable) |
| 11 | Cast Validity Certificate (If Applicable) |
| 12 | Non Creamy-layer (If Applicable) |
| 13 | Income Certificate (If Applicable) |
| 14 | EWS Certificate (If Applicable) |
| 15 | Gap Certificate (If Applicable) |
| 16 | Aadhar Card Xerox |
| 17 | APAAR/ABC ID Xerox |
| 18 | Passport Size 2 Photo |

- Staff Sign, Student Sign, Date

> This is the checklist that **drives Stage 2** of the workflow — each "Yes"-ticked row generates an upload slot in the Document Upload module.

### 6.3 Form 3 — APPLICATION FOR ELIGIBILITY (Savitribai Phule Pune University)

**Header (non-editable):** SPPU crest/name, "Application for Eligibility (For Under Graduate Courses only)", Form fee Rs.50/-, Roll No/Admission No (office use).

**Fields:**
1. Name of Course to which admission is sought + Year (1st/2nd/3rd/4th/5th)
2. Name of Applicant (English capital letters) — with note that N.R.I. students write name as per passport
3. Mother's Name
4. Aadhar No.
5. Mobile No.
6. PAN No.
7. Email Id
8. Type — `Maharashtrian / Non-Maharashtrian`
9. Nationality
10. Religion
11. Gender — `Male / Female / Transgender`
12. Date of Birth — DD / MM / YYYY
13. Category (tick applicable): `Open / SC / ST / DT(A) / NT(B) / NT(C) / NT(D) / OBC / SBC / SEBC / EWS`
   - Sub-question: "Do you belong to DT(A)/NT(B)/NT(C)/NT(D)/OBC/SBC/SEBC or EWS?" — Yes/No (with note: attach Non-Creamy Layer certificate if Yes)
14. Physically Disabled — Yes/No + Type (reference table: P1 Blind/Visually Impaired, P2 Dumb & Deaf, P3 Orthopedically Impaired, P4 Mentally Challenged, OT Other)
15. **Particulars of Qualifying Examination:**
    - Name of Course, Duration of Course, Name of University, Name of College/Institute/University Dept.
    - Table: Seat No. / Month & Year of Passing / Percentage / Class-Grade
    - **Educational Gap details (if any):** Last Examination Name / Seat No. / Month & Year of Passing / Percentage / Class-Grade
16. Minority — Yes/No; if Yes: Linguistic / Religion checkboxes
- Signature of Candidate

**Office-use block:** Receipt No., Date, Eligible/Not Eligible, Asst., Sr. Asst., O.S./Registrar/HOD signoff.

**Attached-certificates reference list (static, for admin cross-check against Form 2's checklist):** Statement of Marks, Educational Gap Certificate, Affidavit for change in name, Domicile Certificate, Caste Certificate, Caste Validity Certificate, Transfer Certificate, Migration Certificate.

**Annexure 'A' Eligibility Fee table** — static reference table (Within Maharashtra / Outside Maharashtra / Foreign, Non-Professional vs Professional fee amounts) rendered as-is on print; not user-editable.

### 6.4 Form 4 — ANNEXURE I: AFFIDAVIT BY THE STUDENT (Anti-Ragging)

**Editable fields only:**
1. Full name of student with admission/registration/enrolment number
2. S/o · D/o Mr./Mrs./Ms. [Parent Name]
3. Admitted to (name of institution) — can auto-fill as the college name
4. Declared this ___ day of ___ month of ___ year
5. Signature of Deponent (name)
6. Verification block: Verified at Place ___ on this ___ day of ___ month of ___ year + Signature of Deponent
7. Oath Commissioner section — left blank for physical notarization (this is a legal affidavit; the "Solemnly affirmed..." line and Oath Commissioner signature happen outside the digital system, on the printed copy)

**Static legal text (must print verbatim, not user-editable):**
- Clauses 1–6 of the UGC Anti-Ragging Regulations undertaking (full text as in the source PDF)
- "VERIFICATION" declaration paragraph
- "Solemnly affirmed and signed in my presence..." Oath Commissioner line

### 6.5 Form 5 — LIBRARY MEMBERSHIP FORM (Student)

**Header (non-editable):** Shetkari Shikshan Mandal / BSCOER letterhead, "Library Membership Form – Student".

**Fields:**
1. Name of Member — Surname / First Name / Father Name (IN CAPITAL)
2. Branch/Department
3. Year — `F.E. / S.E. / M.E. / Ph.D.`
4. Diploma — `FY / DSY`
5. Permanent Address + City + Pin Code
6. Local Address + City + Pin Code
7. E-Mail ID
8. Date of Birth
9. Gender — `Male / Female`
10. Blood Group
11. Student Mobile No. + Parents Tel. No.
12. Cast Category — `Open / SC / ST / VJ / NT1 / NT2 / NT3 / SBC / Other`
13. Student's Admission Receipt No.
14. Admission Date
- Passport-size colour photo (reuse the photo captured in Form 1)
- Signature
- Date, Admin Officer/Accountant Sign.

**For Library Use Only (admin-entered):** Library Membership/I-Card No., Remark, Librarian Sign.

**Second page — Library Rules & Regulations (static, print verbatim):** 13 numbered rules + the declaration "I have read the rules and regulations and ready to follow the same. If any student lost the I-card then I-card will reissue with Rs. 200/- fine." + Date/Signature line.
> UI equivalent: a scrollable rules panel with a mandatory **"I have read and agree"** checkbox before the student can proceed, mirroring the physical signature-under-declaration pattern.

---

## 7. Shared Field Auto-Fetch Map

Single entry point per field; propagates to every form marked ✓. Operator can still edit a propagated value locally if a form needs a variant (e.g. all-caps formatting), but the *first* entry point becomes the canonical source of truth stored on the Admission Record.

| Field | Form 1 (Application) | Form 2 (Doc List) | Form 3 (Eligibility) | Form 4 (Affidavit) | Form 5 (Library) |
|---|:---:|:---:|:---:|:---:|:---:|
| Student Full Name | ✓ (split: Surname/Name) | ✓ | ✓ (capital letters) | ✓ | ✓ (split: Surname/First/Father) |
| Father's Name | ✓ | – | (part of name) | ✓ (as S/o) | ✓ (as Father Name) |
| Mother's Name | ✓ | – | ✓ | – | – |
| Date of Birth | ✓ | – | ✓ | – | ✓ |
| Gender | ✓ (Sex) | – | ✓ (incl. Transgender) | – | ✓ |
| Blood Group | ✓ | – | – | – | ✓ |
| Mobile No. | ✓ | ✓ | ✓ | – | ✓ (+ Parents Tel) |
| Email | ✓ | ✓ | ✓ | – | ✓ |
| Religion & Caste / Category | ✓ | – | ✓ (detailed reservation categories) | – | ✓ (Cast Category) |
| Branch/Course | ✓ | ✓ | ✓ (Course) | – | ✓ (Department) |
| Admission Year | ✓ (Year 20__-20__) | ✓ | ✓ | – | – |
| Correspondence/Local Address + Pin | ✓ | – | – | – | ✓ |
| Permanent Address + Pin | ✓ | – | – | – | ✓ |
| Aadhar No. | – | (Aadhar Xerox doc) | ✓ | – | – |
| Photo (passport size) | ✓ (photo box) | – | – | – | ✓ (reused) |
| Admission Receipt No. | – | – | (Roll No/Admission No – office) | – | ✓ |
| Institution Name | (letterhead, fixed) | (letterhead, fixed) | – | ✓ | (letterhead, fixed) |

**Rule of thumb:** whichever of the 5 forms the operator reaches *first* for a given field becomes the source; subsequent forms show the value pre-filled but editable, with a subtle "auto-filled" indicator so the operator knows it can be corrected per-form without affecting the source.

---

## 8. Document Upload & Verification Module — Requirements

- Upload slots are **generated dynamically** from Form 2's ticked checklist — no manual re-entry of document names.
- Each slot supports: Scan capture, Drag-and-drop, Browse/upload.
- File constraints: image (JPG/PNG) or PDF, reasonable max size, auto-orientation correction on scan.
- **Two-layer verification:**
  1. **System (auto) check:** file integrity, non-blank, correct format — flags obvious problems immediately.
  2. **Admin (manual) check:** Preview → tick "Received: Yes/No" → click "Verified."
- Slot states: `Not Uploaded → Uploaded (Pending Review) → Verified` (or `Rejected – Reupload Required`).
- Stage-2 completion requires all *required* (ticked) slots to reach `Verified`.

---

## 9. Fee Payment Module — Requirements

| Field | Type |
|---|---|
| Total Fee Amount | currency |
| Amount Paid (this entry) | currency |
| Remaining Balance | auto-calculated |
| Mode of Payment | `Cash / UPI / Bank to Bank / RTGS / DD` |
| Installment Plan? | toggle |
| — Installment No. | auto-increment, if enabled |
| — Installment Amount | currency |
| — Installment Mode | same options as above |
| — Installment Date | date |
| — Remaining After Installment | auto-calculated |

Fee status badge (Unpaid / Partially Paid / Fully Paid) should be visible on the student's dashboard row at all times.

---

## 10. Print/Preview Requirements

- Print output must be **byte-for-byte structurally faithful** to the 5 original templates — since printing happens on **blank paper**, Scholaris *is* the template: exact headers, crest, table grids, checkbox glyphs, underline fields, static legal text, and office-use sections all must render correctly, not just the filled-in data.
- Preview mode = exact WYSIWYG of the print output, viewable and re-editable before commit.
- Output should bundle all 5 forms as one paginated document (suggested export as print-ready PDF; PDF generation approach can follow the platform's document-generation skill/tooling at build time).
- Font, spacing, and table alignment should be validated against a physical printout before go-live, since even small drift breaks the "prescribed layout" requirement your college mandates.

---

## 11. Admin Dashboard — Design Spec (Phase 1 Deliverable)

### 11.1 Tone & Visual Direction
**Warm, calm, professional.** Practically, this means:
- Warm neutral background (soft ivory/warm-white, not stark white or cold gray)
- A single confident accent color (muted terracotta, warm amber, or deep teal — avoid saturated "SaaS blue" default) used sparingly for primary actions and status
- Generous whitespace, soft shadows, rounded-but-restrained corners — avoid playful/childish roundness
- Calm status colors: muted sage green (verified/complete), warm amber (pending), soft clay/red (blocked/rejected) — no harsh neon alerts
- Clear serif or well-spaced humanist sans for headings to feel institutional, paired with a clean sans for data/tables
- No visual clutter: one primary action per screen state, secondary actions de-emphasized

### 11.2 Core Dashboard Screens
1. **Overview / Home** — pipeline funnel showing counts at each of the 9 statuses (§5); quick stats (today's new admissions, pending verifications, pending fee balances)
2. **Student Pipeline List** — table/kanban of all in-progress admissions, filterable by status, branch, category; each row shows a compact progress indicator (which of the 6 stages is complete)
3. **New Admission → 5-Form Wizard** — the guided stepper described in §4.1
4. **Document Verification Workspace** — per-student checklist + preview + verify actions (§4.2/§8)
5. **Fee Entry Screen** — per-student fee form (§4.3/§9)
6. **Preview & Print Screen** — full 5-form WYSIWYG render + Print action (§4.4/§10)
7. **Final Verification Queue** — higher-authority view: read-only digital record + "Mark Verified" (password-gated) action (§4.5)
8. **Admitted Students Registry** — final searchable database view (§4.6)

### 11.3 Interaction Principles
- Every irreversible action (save-after-5-forms, final admission) is password-gated, per your spec — modal-based password prompt, not a full page redirect, to keep flow calm and uninterrupted.
- Autosave drafts at every step so an interrupted session never loses data.
- Clear breadcrumb/stepper at all times so the operator always knows which of the 6 stages and which of the 5 forms they're in.

---

## 12. Data Model (High-Level)

```
AdmissionRecord
 ├─ id, status, created_at, updated_at
 ├─ StudentProfile (canonical shared fields — §7)
 ├─ Form1_Application       (full field set — §6.1)
 ├─ Form2_DocumentChecklist (18 rows, ticked/not — §6.2)
 ├─ Form3_Eligibility       (full field set — §6.3)
 ├─ Form4_AntiRaggingAffidavit (full field set — §6.4)
 ├─ Form5_LibraryMembership (full field set — §6.5)
 ├─ DocumentUploads[]       (doc_type, file_ref, status, verified_by, verified_at)
 ├─ FeeRecord               (total, paid, mode, installments[] — §9)
 ├─ PrintLog[]              (printed_at, printed_by, version)
 ├─ VerificationLog[]       (verified_by, role, timestamp, password_confirmed: true)
 └─ AdmittedStudent (final, immutable snapshot — populated on ADMITTED)
```

---

## 13. Non-Functional Requirements

| Category | Requirement |
|---|---|
| Data Integrity | No form field silently lost between auto-fetch propagation and per-form override |
| Auditability | Every verification/password action logged with actor + timestamp |
| Fidelity | Printed output must visually match original stationery layout (validated by physical print test) |
| Performance | Document preview and print-render should feel instant (<2s) for a single student record |
| Security | Password gates are not cosmetic — enforce server-side, not just UI-side |
| Accessibility | Dashboard usable on a standard front-desk laptop/desktop resolution; touch-friendly for tablet-based scanning stations |
| Multi-tenancy readiness | Even though v1 hardcodes this college's templates, keep form schemas data-driven (not hardcoded UI) so a second college's differently-worded forms can be onboarded later without a rewrite |

---

## 14. Open Questions / Assumptions (flag before build)

1. **Signatures:** Are "Signature of Student/Parent/Deponent" fields captured digitally (signature pad/upload) in the app, or always left blank for wet-ink signing on the printed copy? (Recommended: leave blank on print, since Form 4 is a notarized affidavit and needs physical signing anyway — assume this for all forms unless told otherwise.)
2. **Oath Commissioner / Notary section (Form 4):** Confirmed out of digital scope — happens entirely on the physical printout. PRD assumes this.
3. **Rejection/Hold path:** Physical workflow as described has no explicit "reject" state — recommend adding `ON_HOLD` / `REJECTED` statuses so incomplete or ineligible candidates don't get stuck mid-pipeline. Please confirm desired behavior.
4. **Multiple operators per student:** Can different admins handle Stage 1 vs Stage 2 vs Stage 3 for the same student, or is it always one person end-to-end? Affects whether stage hand-off needs a "assign to" field.
5. **Editing after ADMITTED:** Locked by design (§4.5) — confirm whether any post-admission correction workflow is needed (e.g., name spelling fix) and if so, whether it requires the same password gate plus a change-log entry.
6. **APAAR/ABC ID and Aadhar numbers:** These are sensitive identifiers — confirm storage/encryption requirements at rest, since this PRD's data model should flag them for extra protection.

---

## 15. Success Metrics (Phase 1)

- 100% of the 5 forms' fields represented and print-validated against physical originals
- Time to complete all 5 forms for one candidate reduced vs. paper baseline
- Zero data-entry duplication for shared fields (auto-fetch working across all 5 forms)
- Document verification completion rate tracked per admission cycle
- Dashboard usability: front-desk staff able to complete a full admission end-to-end without external instructions after a single walkthrough

---

## 16. Out of Scope for This PRD

- ID card generation, attendance module, academic records — these are downstream Scholaris modules outside the Admission Form module's boundary, though the `AdmittedStudent` record (§12) is designed to feed them.
- Online/automated payment processing.
- Student-facing self-fill portal.

---

*End of PRD.*
