"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  PlusCircle,
  ListTodo,
  ShieldCheck,
  ScrollText,
  LogOut,
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admissions/new", label: "New Admission", icon: PlusCircle },
  { href: "/pipeline", label: "Pipeline", icon: ListTodo },
  { href: "/final-verification", label: "Final Verification", icon: ShieldCheck },
  { href: "/registry", label: "Registry", icon: ScrollText },
];

export function Sidebar({ userName }: { userName?: string | null }) {
  const pathname = usePathname();

  return (
    <aside className="flex h-full w-56 flex-col border-r border-border bg-surface-muted">
      <div className="flex h-14 items-center gap-2 border-b border-border px-4" aria-label="Brand">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent text-sm font-bold text-white" aria-hidden="true">
          S
        </div>
        <div>
          <p className="text-sm font-semibold leading-tight text-foreground">Scholaris</p>
          <p className="text-[10px] leading-tight text-muted-foreground">Admission Module</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 p-3" aria-label="Main navigation">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined}>
              <span
                className={cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  active
                    ? "bg-accent/10 text-accent"
                    : "text-muted-foreground hover:bg-surface-hover hover:text-foreground",
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-border p-3" role="contentinfo">
        <p className="mb-2 truncate text-xs text-muted-foreground">{userName ?? "User"}</p>
        <Link href="/api/auth/signout">
          <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-xs h-8">
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            Sign Out
          </Button>
        </Link>
      </div>
    </aside>
  );
}
