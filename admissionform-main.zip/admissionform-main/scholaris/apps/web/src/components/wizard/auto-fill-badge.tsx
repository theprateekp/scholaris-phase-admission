"use client";

import { cn } from "@/lib/utils";

interface AutoFillBadgeProps {
  visible: boolean;
  className?: string;
}

export function AutoFillBadge({ visible, className }: AutoFillBadgeProps) {
  if (!visible) return null;

  return (
    <span
      className={cn(
        "ml-1 inline-flex items-center rounded-full bg-pending/10 px-1.5 py-0.5 text-[10px] font-medium text-pending",
        className
      )}
      title="Auto-filled from previously entered data"
    >
      auto-filled
    </span>
  );
}
