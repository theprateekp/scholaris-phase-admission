"use client";

import { UseFormReturn, useWatch } from "react-hook-form";
import { Form2Values } from "@/lib/forms/form2-checklist";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AutoFillBadge } from "@/components/wizard/auto-fill-badge";

interface Form2StepProps {
  form: UseFormReturn<Form2Values>;
  autoFilledFields: Set<string>;
}

export function Form2Step({ form, autoFilledFields }: Form2StepProps) {
  const { register, control, setValue } = form;
  const items = useWatch({ control, name: "items" });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Document Checklist Details</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>Admission Type</Label>
            <select {...register("admissionType")} className="flex h-8 w-full rounded-lg border border-input bg-background px-2.5 text-sm">
              <option value="">Select...</option>
              <option value="FE">FE</option>
              <option value="DSE">DSE</option>
            </select>
          </div>
          <div className="space-y-2">
            <Label>
              Cap ID
              <AutoFillBadge visible={autoFilledFields.has("capId")} />
            </Label>
            <Input {...register("capId")} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Checklist (Tick documents received)</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 pr-2 w-10">Sr.</th>
                <th className="text-left py-2 pr-2">Document Name</th>
                <th className="text-center py-2 w-24">Required</th>
              </tr>
            </thead>
            <tbody>
              {items?.map((item, i) => (
                <tr key={i} className="border-b border-border/50">
                  <td className="py-2 pr-2 text-muted-foreground">{item.srNo}</td>
                  <td className="py-2 pr-2">{item.documentName}</td>
                  <td className="py-2 text-center">
                    <Checkbox
                      checked={item.required}
                      onCheckedChange={(checked) =>
                        setValue(`items.${i}.required`, checked === true)
                      }
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
