"use client";

import { UseFormReturn } from "react-hook-form";
import { Form1Values } from "@/lib/forms/form1-application";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AutoFillBadge } from "@/components/wizard/auto-fill-badge";

interface Form1StepProps {
  form: UseFormReturn<Form1Values>;
  autoFilledFields: Set<string>;
}

export function Form1Step({ form, autoFilledFields }: Form1StepProps) {
  const { register, setValue, watch } = form;
  const admissionQuota = watch("admissionQuota");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Admission Details</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>
              Admission Quota
              <AutoFillBadge visible={autoFilledFields.has("admissionQuota")} />
            </Label>
            <Select
              value={admissionQuota ?? ""}
              onValueChange={(v) => setValue("admissionQuota", v as any)}
            >
              <SelectTrigger><SelectValue placeholder="Select quota" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="CAP_CET_AIEEE">CAP (CET/AIEEE)</SelectItem>
                <SelectItem value="JK">J&K</SelectItem>
                <SelectItem value="MGMT">MGMT</SelectItem>
                <SelectItem value="AGAINST_CAP">AGAINST CAP</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>
              Admission Category
              <AutoFillBadge visible={autoFilledFields.has("admissionCategory")} />
            </Label>
            <select
              {...register("admissionCategory")}
              className="flex h-8 w-full rounded-lg border border-input bg-background px-2.5 text-sm"
            >
              <option value="">Select...</option>
              {["Open","OBC","SBC","NT1","NT2","NT3","SC","ST","DEF","PH"].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label>Home University</Label>
            <Input {...register("homeUniversity")} />
          </div>
          <div className="space-y-2">
            <Label>Mother Tongue</Label>
            <Input {...register("motherTongue")} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">S.S.C. Marks</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2"><Label>English Obtained</Label><Input type="number" step="0.01" {...register("sscMarksEnglishObtained")} /></div>
          <div className="space-y-2"><Label>English Out Of</Label><Input type="number" step="0.01" {...register("sscMarksEnglishOutOf")} /></div>
          <div className="space-y-2"><Label>Maths Obtained</Label><Input type="number" step="0.01" {...register("sscMarksMathsObtained")} /></div>
          <div className="space-y-2"><Label>Maths Out Of</Label><Input type="number" step="0.01" {...register("sscMarksMathsOutOf")} /></div>
          <div className="space-y-2"><Label>Grand Total Obtained</Label><Input type="number" step="0.01" {...register("sscGrandTotalObtained")} /></div>
          <div className="space-y-2"><Label>Grand Total Out Of</Label><Input type="number" step="0.01" {...register("sscGrandTotalOutOf")} /></div>
          <div className="space-y-2"><Label>Percentage</Label><Input type="number" step="0.01" {...register("sscPercentage")} /></div>
          <div className="space-y-2"><Label>Year of Passing</Label><Input type="number" {...register("sscYearOfPassing")} /></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">H.S.C. Marks</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2"><Label>Physics Obtained</Label><Input type="number" step="0.01" {...register("hscPhysicsObtained")} /></div>
          <div className="space-y-2"><Label>Physics Out Of</Label><Input type="number" step="0.01" {...register("hscPhysicsOutOf")} /></div>
          <div className="space-y-2"><Label>Chemistry Obtained</Label><Input type="number" step="0.01" {...register("hscChemistryObtained")} /></div>
          <div className="space-y-2"><Label>Chemistry Out Of</Label><Input type="number" step="0.01" {...register("hscChemistryOutOf")} /></div>
          <div className="space-y-2"><Label>Maths Obtained</Label><Input type="number" step="0.01" {...register("hscMathsObtained")} /></div>
          <div className="space-y-2"><Label>Maths Out Of</Label><Input type="number" step="0.01" {...register("hscMathsOutOf")} /></div>
          <div className="space-y-2"><Label>PCM Total Obtained</Label><Input type="number" step="0.01" {...register("hscPcmTotalObtained")} /></div>
          <div className="space-y-2"><Label>PCM Total Out Of</Label><Input type="number" step="0.01" {...register("hscPcmTotalOutOf")} /></div>
          <div className="space-y-2"><Label>Grand Total Obtained</Label><Input type="number" step="0.01" {...register("hscGrandTotalObtained")} /></div>
          <div className="space-y-2"><Label>Grand Total Out Of</Label><Input type="number" step="0.01" {...register("hscGrandTotalOutOf")} /></div>
          <div className="space-y-2"><Label>Year of Passing</Label><Input type="number" {...register("hscYearOfPassing")} /></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">CET Marks</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2"><Label>Physics Obtained</Label><Input type="number" step="0.01" {...register("cetPhysicsObtained")} /></div>
          <div className="space-y-2"><Label>Physics Out Of</Label><Input type="number" step="0.01" {...register("cetPhysicsOutOf")} /></div>
          <div className="space-y-2"><Label>Chemistry Obtained</Label><Input type="number" step="0.01" {...register("cetChemistryObtained")} /></div>
          <div className="space-y-2"><Label>Chemistry Out Of</Label><Input type="number" step="0.01" {...register("cetChemistryOutOf")} /></div>
          <div className="space-y-2"><Label>Maths Obtained</Label><Input type="number" step="0.01" {...register("cetMathsObtained")} /></div>
          <div className="space-y-2"><Label>Maths Out Of</Label><Input type="number" step="0.01" {...register("cetMathsOutOf")} /></div>
          <div className="space-y-2"><Label>PCM Total Obtained</Label><Input type="number" step="0.01" {...register("cetPcmTotalObtained")} /></div>
          <div className="space-y-2"><Label>PCM Total Out Of</Label><Input type="number" step="0.01" {...register("cetPcmTotalOutOf")} /></div>
          <div className="space-y-2"><Label>Exam Seat No.</Label><Input {...register("cetExamSeatNo")} /></div>
          <div className="space-y-2"><Label>Merit No.</Label><Input {...register("cetMeritNo")} /></div>
          <div className="space-y-2"><Label>AIEEE Marks</Label><Input {...register("aieeeMarks")} /></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Diploma (if applicable)</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-2"><Label>Obtained</Label><Input type="number" step="0.01" {...register("diplomaMarksObtained")} /></div>
          <div className="space-y-2"><Label>Out Of</Label><Input type="number" step="0.01" {...register("diplomaMarksOutOf")} /></div>
          <div className="space-y-2"><Label>Branch/Course</Label><Input {...register("diplomaBranchCourse")} /></div>
          <div className="space-y-2"><Label>B.T.E. Enrollment No.</Label><Input {...register("diplomaBteEnrollmentNo")} /></div>
          <div className="space-y-2"><Label>Year of Passing</Label><Input type="number" {...register("diplomaYearOfPassing")} /></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Additional Info</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2"><Label>Annual Income of Parent (Rs.)</Label><Input type="number" step="0.01" {...register("annualIncomeOfParent")} /></div>
          <div className="space-y-2"><Label>Date</Label><Input type="date" {...register("dateField")} /></div>
          <div className="space-y-2"><Label>Place</Label><Input {...register("placeField")} /></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">For Office Use Only</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2"><Label>Eligible For</Label><Input {...register("officeUseEligibleFor")} /></div>
          <div className="space-y-2">
            <Label>Branch</Label>
            <select {...register("officeUseBranch")} className="flex h-8 w-full rounded-lg border border-input bg-background px-2.5 text-sm">
              <option value="">Select...</option>
              {["Civil","Comp","ETC","IT","Mech","Elect"].map((b) => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
