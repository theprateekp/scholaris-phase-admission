"use client";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { WizardStepper } from "@/components/wizard/wizard-stepper";
import { ReviewModal } from "@/components/wizard/review-modal";
import { PasswordGateModal } from "@/components/wizard/password-gate-modal";
import { Form1Step } from "@/components/wizard/steps/form1-step";
import { Form2Step } from "@/components/wizard/steps/form2-step";
import { Form3Step } from "@/components/wizard/steps/form3-step";
import { Form4Step } from "@/components/wizard/steps/form4-step";
import { Form5Step } from "@/components/wizard/steps/form5-step";
import { form1Schema, Form1Values, FORM1_DEFAULT_VALUES } from "@/lib/forms/form1-application";
import { form2Schema, Form2Values, createForm2DefaultValues } from "@/lib/forms/form2-checklist";
import { form3Schema, Form3Values, FORM3_DEFAULT_VALUES } from "@/lib/forms/form3-eligibility";
import { form4Schema, Form4Values, FORM4_DEFAULT_VALUES } from "@/lib/forms/form4-affidavit";
import { form5Schema, Form5Values, FORM5_DEFAULT_VALUES } from "@/lib/forms/form5-library";
import { FORM_LABELS } from "@/lib/forms";
import { createAdmissionRecord, saveFormData, saveChecklistItems, verifyFormsPassword, updateStudentProfile } from "@/lib/actions/admission";
import { AutoFillBadge } from "@/components/wizard/auto-fill-badge";

interface FormData {
  form1: Form1Values;
  form2: Form2Values;
  form3: Form3Values;
  form4: Form4Values;
  form5: Form5Values;
}

export function WizardClient() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [recordId, setRecordId] = useState<string | null>(null);
  const [showReview, setShowReview] = useState(false);
  const [showPasswordGate, setShowPasswordGate] = useState(false);
  const [pending, setPending] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [autoFilledFields, setAutoFilledFields] = useState<Set<string>>(new Set());
  const [studentProfile, setStudentProfile] = useState<Record<string, unknown>>({});

  const formDataRef = useRef<FormData>({
    form1: FORM1_DEFAULT_VALUES,
    form2: createForm2DefaultValues(),
    form3: FORM3_DEFAULT_VALUES,
    form4: FORM4_DEFAULT_VALUES,
    form5: FORM5_DEFAULT_VALUES,
  });

  const form1 = useForm<Form1Values>({
    resolver: zodResolver(form1Schema),
    defaultValues: FORM1_DEFAULT_VALUES,
  });

  const form2 = useForm<Form2Values>({
    resolver: zodResolver(form2Schema),
    defaultValues: createForm2DefaultValues(),
  });

  const form3 = useForm<Form3Values>({
    resolver: zodResolver(form3Schema),
    defaultValues: FORM3_DEFAULT_VALUES,
  });

  const form4 = useForm<Form4Values>({
    resolver: zodResolver(form4Schema),
    defaultValues: FORM4_DEFAULT_VALUES,
  });

  const form5 = useForm<Form5Values>({
    resolver: zodResolver(form5Schema),
    defaultValues: FORM5_DEFAULT_VALUES,
  });

  const forms = [form1, form2, form3, form4, form5];

  const updateAutoFill = useCallback((formKey: string, values: Record<string, unknown>) => {
    const newAutoFilled = new Set(autoFilledFields);
    for (const [field, value] of Object.entries(values)) {
      if (value !== null && value !== undefined && value !== "") {
        newAutoFilled.add(field);
      }
    }
    setAutoFilledFields(newAutoFilled);
  }, [autoFilledFields]);

  const handleFieldChange = useCallback(async (formKey: string, fieldName: string, value: unknown) => {
    if (!recordId) return;
    const profileFields: Record<string, string> = {
      fullNameSurname: "fullNameSurname",
      fullNameFirst: "fullNameFirst",
      fullNameFather: "fullNameFather",
      fatherName: "fatherName",
      motherName: "motherName",
      dateOfBirth: "dateOfBirth",
      gender: "gender",
      bloodGroup: "bloodGroup",
      mobileNo: "mobileNo",
      email: "email",
      religionCaste: "religionCaste",
      category: "category",
      branchCourse: "branchCourse",
      contactTelNo: "contactTelNo",
      correspondenceTelNo: "correspondenceTelNo",
      permanentTelNo: "permanentTelNo",
      correspondenceAddress: "correspondenceAddress",
      correspondencePin: "correspondencePin",
      permanentAddress: "permanentAddress",
      permanentPin: "permanentPin",
      permanentCity: "permanentCity",
      admissionReceiptNo: "admissionReceiptNo",
      admissionDate: "admissionDate",
    };

    const profileField = profileFields[fieldName];
    if (profileField && value !== null && value !== undefined && value !== "") {
      const newProfile = { ...studentProfile, [profileField]: value };
      setStudentProfile(newProfile);
      await updateStudentProfile(recordId, newProfile);
    }
  }, [recordId, studentProfile]);

  async function handleReviewConfirm() {
    setErrorMessage(null);
    setPending(true);

    try {
      const currentForm = forms[currentStep];
      const isValid = await currentForm.trigger();
      if (!isValid) {
        setPending(false);
        return;
      }

      const values = currentForm.getValues();
      const formKey = `form${currentStep + 1}` as "form1" | "form2" | "form3" | "form4" | "form5";
      formDataRef.current[formKey] = values as any;

      let activeId = recordId;
      if (!activeId) {
        const result = await createAdmissionRecord();
        activeId = result.id;
        setRecordId(result.id);
      }

      let saveResult: { success: boolean; error?: string };

      if (formKey === "form2") {
        saveResult = await saveChecklistItems(activeId, (values as Form2Values).items.map((item, i) => ({
          srNo: i + 1,
          documentName: item.documentName,
          required: item.required,
        })));

        if (saveResult.success) {
          saveResult = await saveFormData(activeId, "form2", {
            admissionType: (values as Form2Values).admissionType,
            capId: (values as Form2Values).capId,
            staffSignRef: (values as Form2Values).staffSignRef,
            studentSignRef: (values as Form2Values).studentSignRef,
            checklistDate: (values as Form2Values).checklistDate,
          });
        }
      } else {
        saveResult = await saveFormData(activeId, formKey, values as Record<string, unknown>);
      }

      if (!saveResult.success) {
        setErrorMessage(saveResult.error || "Failed to save form data");
        setPending(false);
        return;
      }

      const newCompleted = new Set(completedSteps);
      newCompleted.add(currentStep);
      setCompletedSteps(newCompleted);

      setShowReview(false);

      if (currentStep === 4) {
        setShowPasswordGate(true);
      } else {
        setCurrentStep(currentStep + 1);
      }
    } catch (err: any) {
      console.error("Error in handleReviewConfirm:", err);
      setErrorMessage(err.message || "An error occurred while saving form data");
    } finally {
      setPending(false);
    }
  }

  async function handlePasswordVerify(password: string): Promise<boolean> {
    if (!recordId) return false;
    const form5Values = form5.getValues();
    await saveFormData(recordId, "form5", form5Values as Record<string, unknown>);
    const result = await verifyFormsPassword(recordId, password);
    return result.success;
  }

  function handlePasswordSuccess() {
    setShowPasswordGate(false);
    router.push("/");
    router.refresh();
  }

  function handleReviewForm() {
    setErrorMessage(null);
    forms[currentStep].trigger().then((isValid) => {
      if (isValid) setShowReview(true);
    });
  }

  const renderReviewContent = () => {
    const values = forms[currentStep].getValues();
    const label = FORM_LABELS[currentStep];

    return (
      <div className="space-y-3">
        <h3 className="font-medium text-sm text-muted-foreground">{label}</h3>
        <div className="grid grid-cols-2 gap-2 text-sm">
          {Object.entries(values as Record<string, unknown>).map(([key, val]) => {
            if (typeof val === "object") return null;
            if (val === null || val === undefined || val === "") return null;
            return (
              <div key={key} className="col-span-1">
                <span className="text-muted-foreground text-xs block">{key}</span>
                <span className="font-medium">{String(val)}</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-6">
      <div>
        <h1 className="font-heading text-xl font-semibold text-foreground">
          New Admission
        </h1>
        <p className="text-sm text-muted-foreground">
          Form {currentStep + 1} of 5 — {FORM_LABELS[currentStep]}
        </p>
      </div>

      {errorMessage && (
        <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-sm text-red-700 font-medium">
          {errorMessage}
        </div>
      )}

      <WizardStepper currentStep={currentStep} completedSteps={completedSteps} />

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{FORM_LABELS[currentStep]}</CardTitle>
        </CardHeader>
        <CardContent>
          {currentStep === 0 && <Form1Step form={form1} autoFilledFields={autoFilledFields} />}
          {currentStep === 1 && <Form2Step form={form2} autoFilledFields={autoFilledFields} />}
          {currentStep === 2 && <Form3Step form={form3} autoFilledFields={autoFilledFields} />}
          {currentStep === 3 && <Form4Step form={form4} autoFilledFields={autoFilledFields} />}
          {currentStep === 4 && <Form5Step form={form5} autoFilledFields={autoFilledFields} />}
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => { setErrorMessage(null); setCurrentStep(Math.max(0, currentStep - 1)); }}
          disabled={currentStep === 0 || pending}
        >
          Previous
        </Button>
        <Button onClick={handleReviewForm} disabled={pending}>
          {currentStep === 4 ? "Review & Complete" : "Review this form"}
        </Button>
      </div>

      <ReviewModal
        open={showReview}
        onOpenChange={setShowReview}
        onConfirm={handleReviewConfirm}
        title={`Review: ${FORM_LABELS[currentStep]}`}
      >
        {renderReviewContent()}
      </ReviewModal>

      <PasswordGateModal
        open={showPasswordGate}
        onOpenChange={setShowPasswordGate}
        title="Complete Admission Record"
        description="Enter the Admin Password to save this Admission Record and advance to Document Upload."
        onVerify={handlePasswordVerify}
        onSuccess={handlePasswordSuccess}
      />
    </div>
  );
}
