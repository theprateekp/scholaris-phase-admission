"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { DocumentSlotCard } from "@/components/documents/document-slot-card";
import {
  getDocumentSlots,
  uploadDocument,
  setReceivedStatus,
  verifyDocument,
  rejectDocument,
} from "@/lib/actions/documents";

interface UploadData {
  id: string;
  fileRef: string | null;
  fileType: string | null;
  status: "NOT_UPLOADED" | "UPLOADED_PENDING_REVIEW" | "VERIFIED" | "REJECTED_REUPLOAD";
  systemCheckPassed: boolean | null;
  systemCheckNotes: string | null;
  receivedYn: boolean | null;
}

interface SlotData {
  checklistItemId: string;
  srNo: number;
  documentName: string;
  upload: UploadData | null;
}

interface DocumentsClientProps {
  recordId: string;
  currentStatus: string;
}

export function DocumentsClient({ recordId, currentStatus }: DocumentsClientProps) {
  const router = useRouter();
  const [slots, setSlots] = useState<SlotData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSlots();
  }, [recordId]);

  async function loadSlots() {
    setLoading(true);
    const data = await getDocumentSlots(recordId);
    setSlots(data);
    setLoading(false);
  }

  const handleUpload = useCallback(async (checklistItemId: string, file: File, method: string) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("uploadMethod", method);
    await uploadDocument(recordId, checklistItemId, formData);
    await loadSlots();
    router.refresh();
  }, [recordId, router]);

  const handleSetReceived = useCallback(async (uploadId: string, received: boolean) => {
    await setReceivedStatus(uploadId, received);
    await loadSlots();
  }, []);

  const handleVerify = useCallback(async (uploadId: string) => {
    await verifyDocument(uploadId);
    await loadSlots();
    router.refresh();
  }, [router]);

  const handleReject = useCallback(async (uploadId: string, reason: string) => {
    await rejectDocument(uploadId, reason);
    await loadSlots();
  }, []);

  const verifiedCount = slots.filter((s) => s.upload?.status === "VERIFIED").length;
  const totalRequired = slots.length;

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl font-semibold text-foreground">
            Document Verification
          </h1>
          <p className="text-sm text-muted-foreground">
            Upload and verify required documents. Status: {currentStatus}
          </p>
        </div>
        <div className="text-sm text-muted-foreground">
          {verifiedCount} / {totalRequired} verified
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12 text-sm text-muted-foreground">
          Loading document slots...
        </div>
      ) : slots.length === 0 ? (
        <div className="rounded-lg border border-border bg-surface-muted p-8 text-center text-sm text-muted-foreground">
          No required documents. Complete the Document Checklist (Form 2) first.
        </div>
      ) : (
        <div className="space-y-3">
          {slots.map((slot) => (
            <DocumentSlotCard
              key={slot.checklistItemId}
              srNo={slot.srNo}
              documentName={slot.documentName}
              checklistItemId={slot.checklistItemId}
              recordId={recordId}
              upload={slot.upload}
              onUpload={handleUpload}
              onSetReceived={handleSetReceived}
              onVerify={handleVerify}
              onReject={handleReject}
            />
          ))}
        </div>
      )}
    </div>
  );
}
