import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { WizardClient } from "./wizard-client";

export default async function NewAdmissionPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  return <WizardClient />;
}
