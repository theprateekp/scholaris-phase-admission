"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { approvePreview, markPrinted } from "@/lib/actions/print";

interface PreviewClientProps {
  recordId: string;
  currentStatus: string;
}

export function PreviewClient({ recordId, currentStatus }: PreviewClientProps) {
  const [status, setStatus] = useState(currentStatus);
  const [pending, setPending] = useState(false);

  const canApprove = status === "FEE_RECORDED" || status === "READY_TO_PRINT";
  const canPrint = status === "READY_TO_PRINT" || status === "PRINTED";

  async function handleApprove() {
    setPending(true);
    await approvePreview(recordId);
    setStatus("READY_TO_PRINT");
    setPending(false);
  }

  async function handlePrint() {
    setPending(true);
    const a = document.createElement("a");
    a.href = `/api/print/${recordId}/pdf`;
    a.download = `admission-forms-${recordId}.pdf`;
    a.click();
    await markPrinted(recordId);
    setStatus("PRINTED");
    setPending(false);
  }

  return (
    <div className="mx-auto max-w-4xl space-y-4 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl font-semibold text-foreground">
            Preview &amp; Print
          </h1>
          <p className="text-sm text-muted-foreground">
            Review the filled forms before printing. Status: {status}
          </p>
        </div>
        <div className="flex gap-2">
          {canApprove && (
            <Button onClick={handleApprove} disabled={pending}>
              Approve Preview
            </Button>
          )}
          {canPrint && (
            <Button variant="outline" onClick={handlePrint} disabled={pending}>
              {pending ? "Generating PDF..." : "Download / Print PDF"}
            </Button>
          )}
        </div>
      </div>

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <iframe
            src={`/api/print/${recordId}/html`}
            className="h-[calc(100vh-200px)] w-full border-0"
            title="Form Preview"
          />
        </CardContent>
      </Card>
    </div>
  );
}
