"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PasswordGateModal } from "@/components/wizard/password-gate-modal";
import { FeeStatusBadge } from "@/components/fee/fee-status-badge";
import { admitStudent } from "@/lib/actions/final-verification";

interface PendingRecord {
  id: string;
  status: string;
  createdAt: Date;
  studentProfile: {
    fullNameSurname: string | null;
    fullNameFirst: string | null;
    branchCourse: string | null;
  } | null;
  feeRecord: { feeStatus: string } | null;
}

interface FinalVerificationClientProps {
  pending: PendingRecord[];
}

export function FinalVerificationClient({ pending }: FinalVerificationClientProps) {
  const router = useRouter();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showPasswordGate, setShowPasswordGate] = useState(false);
  const [verifyingId, setVerifyingId] = useState<string | null>(null);

  function handleVerifyClick(recordId: string) {
    setSelectedId(recordId);
    setShowPasswordGate(true);
  }

  async function handlePasswordVerify(password: string): Promise<boolean> {
    if (!selectedId) return false;
    setVerifyingId(selectedId);
    const result = await admitStudent(selectedId, password);
    setVerifyingId(null);
    return result.success;
  }

  function handlePasswordSuccess() {
    setShowPasswordGate(false);
    setSelectedId(null);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6">
      <div>
        <h1 className="font-heading text-xl font-semibold text-foreground">
          Final Verification Queue
        </h1>
        <p className="text-sm text-muted-foreground">
          {pending.length} record{pending.length !== 1 ? "s" : ""} awaiting final verification
        </p>
      </div>

      {pending.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            No records pending final verification.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {pending.map((record) => {
            const name = [record.studentProfile?.fullNameSurname, record.studentProfile?.fullNameFirst]
              .filter(Boolean)
              .join(" ") || "Unnamed";

            return (
              <Card key={record.id}>
                <CardHeader className="flex flex-row items-center justify-between py-3">
                  <div>
                    <CardTitle className="text-sm font-medium">{name}</CardTitle>
                    <p className="text-xs text-muted-foreground">
                      {record.studentProfile?.branchCourse ?? "N/A"} • Created {new Date(record.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <FeeStatusBadge
                      feeStatus={record.feeRecord?.feeStatus ?? null}
                      totalFee={0}
                      amountPaid={0}
                    />
                    <Badge variant="secondary">Pending</Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex gap-2 py-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(`/api/print/${record.id}/html`, "_blank")}
                  >
                    View Digital Record
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleVerifyClick(record.id)}
                    disabled={verifyingId === record.id}
                  >
                    {verifyingId === record.id ? "Verifying..." : "Mark Verified"}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <PasswordGateModal
        open={showPasswordGate}
        onOpenChange={setShowPasswordGate}
        title="Final Verification"
        description="Enter the Verification Password to admit this student."
        onVerify={handlePasswordVerify}
        onSuccess={handlePasswordSuccess}
      />
    </div>
  );
}
