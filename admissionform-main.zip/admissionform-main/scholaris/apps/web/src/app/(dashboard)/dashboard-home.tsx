"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, ShieldCheck, DollarSign } from "lucide-react";
import Link from "next/link";
import type { DashboardStats } from "@/lib/actions/pipeline";

interface DashboardUser {
  id: string;
  name?: string | null;
  email?: string | null;
  role?: string;
}

export function DashboardHome({ user, stats }: { user: DashboardUser; stats: DashboardStats }) {
  return (
    <div className="flex flex-1 flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-semibold text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Welcome, {user.name || "Admin"}</p>
        </div>
        <Link href="/admissions/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Admission
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Today&apos;s New Admissions</CardTitle>
            <Plus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">{stats.todayNewAdmissions}</p>
          </CardContent>
        </Card>
        <Link href="/final-verification" className="block">
          <Card className="cursor-pointer transition-colors hover:border-accent/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Verifications</CardTitle>
              <ShieldCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{stats.pendingVerifications}</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/pipeline" className="block">
          <Card className="cursor-pointer transition-colors hover:border-accent/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Fee Balances</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{stats.pendingFeeBalances}</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      <Card>
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Status Overview</CardTitle>
          <Link href="/pipeline">
            <Button variant="outline" size="sm">View All</Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {stats.statusCounts.map((s) => (
              <div key={s.status} className="rounded-lg border border-border bg-surface-muted p-3 text-center">
                <p className="text-xs text-muted-foreground">{s.status.replace(/_/g, " ")}</p>
                <p className="text-xl font-bold text-foreground">{s.count}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
