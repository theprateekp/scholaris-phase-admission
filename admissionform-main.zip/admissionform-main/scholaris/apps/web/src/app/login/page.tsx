import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LoginForm } from "./login-form";

export default async function LoginPage() {
  const session = await auth();
  if (session?.user) redirect("/");

  return (
    <div className="flex min-h-svh flex-col items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <h1 className="font-heading text-2xl font-semibold text-foreground">
            Scholaris
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Admission Form Module
          </p>
        </div>
        <LoginForm />
      </div>
    </div>
  );
}
