import { z } from "zod";

export const checklistItemSchema = z.object({
  srNo: z.number(),
  documentName: z.string(),
  required: z.boolean(),
});

export const form2Schema = z.object({
  admissionType: z.enum(["FE", "DSE"]).nullable(),
  capId: z.string().nullable(),
  staffSignRef: z.string().nullable(),
  studentSignRef: z.string().nullable(),
  checklistDate: z.string().nullable(),
  items: z.array(checklistItemSchema).length(18),
});

export type Form2Values = z.infer<typeof form2Schema>;
export type ChecklistItemValues = z.infer<typeof checklistItemSchema>;

export const DOCUMENT_NAMES = [
  "Allotment Letter",
  "Confirmation Letter",
  "S.S.C. Mark sheet",
  "S.S.C. Board Certificate",
  "H.S.C. Mark sheet",
  "H.S.C. Board Certificate",
  "Leaving / TC Certificate",
  "Migration Certificate (If Applicable)",
  "Age, Nationality, Domicile / Birth Certificate",
  "Cast Certificate (If Applicable)",
  "Cast Validity Certificate (If Applicable)",
  "Non Creamy-layer (If Applicable)",
  "Income Certificate (If Applicable)",
  "EWS Certificate (If Applicable)",
  "Gap Certificate (If Applicable)",
  "Aadhar Card Xerox",
  "APAAR/ABC ID Xerox",
  "Passport Size 2 Photo",
] as const;

export function createForm2DefaultValues(): Form2Values {
  return {
    admissionType: null,
    capId: null,
    staffSignRef: null,
    studentSignRef: null,
    checklistDate: null,
    items: DOCUMENT_NAMES.map((name, i) => ({
      srNo: i + 1,
      documentName: name,
      required: false,
    })),
  };
}
