import { PRINT_STYLES } from "./print-styles";
import { PrintFormData } from "./get-form-data";

function v(val: unknown): string {
  if (val === null || val === undefined) return "";
  return String(val);
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function esc(val: unknown): string {
  return escapeHtml(v(val));
}

function td(label: string, val: unknown): string {
  return `<tr><td style="font-weight:bold;width:${label.length > 20 ? '180pt' : '140pt'}">${esc(label)}</td><td>${esc(val)}</td></tr>`;
}

function marksRow(subject: string, obtained: unknown, outOf: unknown): string {
  return `<tr><td>${esc(subject)}</td><td style="text-align:center">${esc(obtained)}</td><td style="text-align:center">${esc(outOf)}</td></tr>`;
}

function renderForm1(d: PrintFormData): string {
  const s = d.student;
  const f = d.form1;
  return `<div class="print-page">
    <div class="header-center">
      <h1>TSSM's Bhivarabai Sawant College of Engineering &amp; Research</h1>
      <div class="sub">Narhe, Pune - 411041 | Phone: 020-24301234</div>
      <div class="form-title">APPLICATION FORM</div>
      <div class="sub">Academic Year: ${esc(s.admissionYearStart)}-${esc(s.admissionYearEnd)}</div>
    </div>
    <div class="photo-box">Passport Size Photo</div>
    <table>${td("Branch/Course", s.branchCourse)}${td("Admission Quota", f.admissionQuota)}${td("Admission Category", s.category)}</table>
    <table>${td("Name of Candidate (Surname)", s.fullNameSurname)}${td("Name (First)", s.fullNameFirst)}${td("Father's Name", s.fatherName)}${td("Mother's Name", s.motherName)}${td("Date of Birth", s.dateOfBirth)}${td("Blood Group", s.bloodGroup)}${td("Sex", s.gender)}${td("Religion &amp; Caste", s.religionCaste)}${td("Contact Tel. No. (STD)", s.contactTelNo)}${td("Mobile No.", s.mobileNo)}${td("Email Address", s.email)}${td("Mother Tongue", f.motherTongue)}${td("Home University", f.homeUniversity)}</table>
    <p style="font-weight:bold;margin:8pt 0 4pt">S.S.C. Marks</p>
    <table class="marks-table"><thead><tr><th>Subject</th><th>Obtained</th><th>Out Of</th></tr></thead><tbody>${marksRow("English", f.sscMarksEnglishObtained, f.sscMarksEnglishOutOf)}${marksRow("Mathematics", f.sscMarksMathsObtained, f.sscMarksMathsOutOf)}<tr><td style="font-weight:bold">Grand Total</td><td style="text-align:center">${esc(f.sscGrandTotalObtained)}</td><td style="text-align:center">${esc(f.sscGrandTotalOutOf)}</td></tr></tbody></table>
    <div>Percentage: ${esc(f.sscPercentage)} | Year of Passing: ${esc(f.sscYearOfPassing)}</div>
    <p style="font-weight:bold;margin:8pt 0 4pt">H.S.C. Marks</p>
    <table class="marks-table"><thead><tr><th>Subject</th><th>Obtained</th><th>Out Of</th></tr></thead><tbody>${marksRow("Physics", f.hscPhysicsObtained, f.hscPhysicsOutOf)}${marksRow("Chemistry", f.hscChemistryObtained, f.hscChemistryOutOf)}${marksRow("Mathematics", f.hscMathsObtained, f.hscMathsOutOf)}<tr><td style="font-weight:bold">PCM Total</td><td style="text-align:center">${esc(f.hscPcmTotalObtained)}</td><td style="text-align:center">${esc(f.hscPcmTotalOutOf)}</td></tr><tr><td style="font-weight:bold">Grand Total</td><td style="text-align:center">${esc(f.hscGrandTotalObtained)}</td><td style="text-align:center">${esc(f.hscGrandTotalOutOf)}</td></tr></tbody></table>
    <div>Year of Passing: ${esc(f.hscYearOfPassing)}</div>
    <p style="font-weight:bold;margin:8pt 0 4pt">CET Marks</p>
    <table class="marks-table"><thead><tr><th>Subject</th><th>Obtained</th><th>Out Of</th></tr></thead><tbody>${marksRow("Physics", f.cetPhysicsObtained, f.cetPhysicsOutOf)}${marksRow("Chemistry", f.cetChemistryObtained, f.cetChemistryOutOf)}${marksRow("Mathematics", f.cetMathsObtained, f.cetMathsOutOf)}<tr><td style="font-weight:bold">PCM Total</td><td style="text-align:center">${esc(f.cetPcmTotalObtained)}</td><td style="text-align:center">${esc(f.cetPcmTotalOutOf)}</td></tr></tbody></table>
    <div>Seat No: ${esc(f.cetExamSeatNo)} | Merit No: ${esc(f.cetMeritNo)} | AIEEE Marks: ${esc(f.aieeeMarks)}</div>
    ${f.diplomaMarksObtained !== null && f.diplomaMarksObtained !== undefined ? `<p style="font-weight:bold;margin:8pt 0 4pt">For Diploma Students</p><table>${td("Marks Obtained", f.diplomaMarksObtained)}${td("Out Of", f.diplomaMarksOutOf)}${td("Branch/Course", f.diplomaBranchCourse)}${td("B.T.E. Enrollment No.", f.diplomaBteEnrollmentNo)}${td("Year of Passing", f.diplomaYearOfPassing)}</table>` : ""}
    <table style="margin-top:8pt">${td("Correspondence Address", s.correspondenceAddress)}${td("Pin Code", s.correspondencePin)}${td("Tel. No. (STD)", s.correspondenceTelNo)}${td("Permanent Address", s.permanentAddress)}${td("Pin Code", s.permanentPin)}${td("Tel. No. (STD)", s.permanentTelNo)}${td("Annual Income of Parent (Rs.)", f.annualIncomeOfParent)}</table>
    <div style="margin-top:12pt"><div>Date: ${esc(f.dateField)}</div><div>Place: ${esc(f.placeField)}</div></div>
    <div style="display:flex;justify-content:space-between;margin-top:20pt"><div class="signature-line">Signature of Parent/Guardian</div><div class="signature-line">Signature of Student</div></div>
    <div class="office-use-box"><h3>For Office Use Only</h3><p>Applicant Mr/Miss _________________ is eligible for the ${esc(f.officeUseEligibleFor)} course for academic year ________ .</p><div style="margin-top:8pt">Branch: ${esc(f.officeUseBranch)}</div><div style="margin-top:16pt;text-align:right" class="signature-line" style="margin-left:auto">Principal</div></div>
  </div>`;
}

function renderForm2(d: PrintFormData): string {
  const s = d.student;
  const f = d.form2;
  let items = "";
  for (const item of d.checklistItems) {
    items += `<tr><td style="text-align:center">${item.srNo}</td><td>${esc(item.documentName)}</td><td style="text-align:center"><span class="checkbox-glyph">${item.required ? '&#9745;' : '&#9744;'}</span></td></tr>`;
  }
  return `<div class="print-page">
    <div class="header-center"><h1>Shetkari Shikshan Mandal</h1><h2>TSSM's Bhivarabai Sawant College of Engineering &amp; Research, Narhe, Pune</h2><div class="form-title">LIST OF DOCUMENTS</div></div>
    <table>${td("Name of Student", `${v(s.fullNameSurname)} ${v(s.fullNameFirst)}`)}${td("Class", f.admissionType)}${td("Branch", s.branchCourse)}${td("Admission Year", `${v(s.admissionYearStart)}-${v(s.admissionYearEnd)}`)}${td("Admission Type", f.admissionType)}${td("Cap ID", f.capId)}${td("Student Mobile No.", s.mobileNo)}${td("Email ID", s.email)}${td("Admission Category", s.category)}</table>
    <table style="margin-top:8pt"><thead><tr><th style="width:30pt;text-align:center">Sr.</th><th>Document Name</th><th style="width:80pt;text-align:center">Received (Yes/No)</th></tr></thead><tbody>${items}</tbody></table>
    <div style="display:flex;justify-content:space-between;margin-top:20pt"><div class="signature-line">Staff Sign</div><div class="signature-line">Student Sign</div><div>Date: ________</div></div>
  </div>`;
}

function renderForm3(d: PrintFormData): string {
  const s = d.student;
  const f = d.form3;
  return `<div class="print-page">
    <div class="header-center"><h1>Savitribai Phule Pune University</h1><div class="form-title">Application for Eligibility (For Under Graduate Courses only)</div><div class="sub">Form Fee: Rs. 50/-</div></div>
    <table>${td("Course seeking admission to", f.courseName)}${td("Year", f.courseYear)}${td("Name of Applicant", `${v(s.fullNameSurname)} ${v(s.fullNameFirst)} ${v(s.fullNameFather)}`)}${td("Mother's Name", s.motherName)}${td("Aadhar No.", s.aadharNoEncrypted ? '********' : '')}${td("Mobile No.", s.mobileNo)}${td("PAN No.", s.panNo)}${td("Email Id", s.email)}${td("Type", f.applicantType)}${td("Nationality", f.nationality)}${td("Religion", f.religion)}${td("Gender", s.gender)}${td("Date of Birth", s.dateOfBirth)}${td("Category", `${v(f.categoryTick)}${f.belongsToReservedYn ? ' (NCL attached)' : ''}`)}${td("Physically Disabled", `${v(f.physicallyDisabledYn)}${f.physicallyDisabledType ? ' - Type: ' + v(f.physicallyDisabledType) : ''}`)}</table>
    <p style="font-weight:bold;margin:8pt 0 4pt">Particulars of Qualifying Examination</p>
    <table><thead><tr><th>Course</th><th>Duration</th><th>University</th><th>College/Institute</th></tr></thead><tbody><tr><td>${esc(f.qualCourseName)}</td><td>${esc(f.qualDuration)}</td><td>${esc(f.qualUniversity)}</td><td>${esc(f.qualCollegeDept)}</td></tr></tbody></table>
    <table><thead><tr><th>Seat No.</th><th>Month &amp; Year of Passing</th><th>Percentage</th><th>Class/Grade</th></tr></thead><tbody><tr><td>${esc(f.qualSeatNo)}</td><td>${esc(f.qualMonthYearPassing)}</td><td>${esc(f.qualPercentage)}</td><td>${esc(f.qualClassGrade)}</td></tr></tbody></table>
    ${f.gapLastExamName ? `<p style="font-weight:bold;margin:8pt 0 4pt">Educational Gap Details</p><table><thead><tr><th>Last Exam Name</th><th>Seat No.</th><th>Month &amp; Year</th><th>Percentage</th><th>Class/Grade</th></tr></thead><tbody><tr><td>${esc(f.gapLastExamName)}</td><td>${esc(f.gapSeatNo)}</td><td>${esc(f.gapMonthYearPassing)}</td><td>${esc(f.gapPercentage)}</td><td>${esc(f.gapClassGrade)}</td></tr></tbody></table>` : ""}
    <table style="margin-top:8pt">${td("Minority", `${v(f.minorityYn)}${f.minorityLinguistic ? ' (Linguistic)' : ''}${f.minorityReligion ? ' (Religion)' : ''}`)}</table>
    <div style="margin-top:16pt" class="signature-line">Signature of Candidate</div>
    <div class="office-use-box" style="margin-top:12pt"><h3>Office Use</h3><div>Receipt No.: ${esc(f.officeReceiptNo)} | Date: ${esc(f.officeDate)}</div><div>Eligible/Not Eligible: ${esc(f.officeEligibleStatus)}</div><div style="display:flex;justify-content:space-between;margin-top:8pt"><div class="signature-line">Asst.</div><div class="signature-line">Sr. Asst.</div><div class="signature-line">O.S./Registrar/HOD</div></div></div>
    <div class="office-use-box" style="margin-top:8pt"><h3>Annexure 'A' — Eligibility Fee</h3><table><thead><tr><th>Category</th><th>Non-Professional</th><th>Professional</th></tr></thead><tbody><tr><td>Within Maharashtra</td><td>Rs. 50/-</td><td>Rs. 100/-</td></tr><tr><td>Outside Maharashtra</td><td>Rs. 200/-</td><td>Rs. 500/-</td></tr><tr><td>Foreign</td><td>US $ 50</td><td>US $ 100</td></tr></tbody></table></div>
  </div>`;
}

function renderForm4(d: PrintFormData): string {
  const f = d.form4;
  return `<div class="print-page">
    <div class="header-center"><h1>AFFIDAVIT BY THE STUDENT</h1><div class="sub">(Against Ragging)</div></div>
    <table>${td("Full name with admission/reg./enrolment no.", f.fullNameWithEnrollmentNo)}${td("S/o · D/o Mr./Mrs./Ms.", f.sonDaughterOf)}${td("Admitted to (institution)", f.admittedToInstitution)}</table>
    <div class="static-legal"><p style="font-weight:bold;margin-bottom:4pt">I/We hereby undertake:</p><ol><li>I admit that ragging is a criminal offence under the UGC Regulations on Curbing the Menace of Ragging in Higher Educational Institutions, 2009.</li><li>I shall not indulge in any act of ragging in or outside the campus.</li><li>I shall not abet or encourage any form of ragging.</li><li>I understand that if found guilty of ragging, I may be expelled from the institution, suspended, or fined, and FIR may be lodged with the police.</li><li>I have read and understood the UGC Anti-Ragging Regulations and the institution's anti-ragging policy.</li><li>I understand that ragging includes any act of physical or mental abuse, teasing, bullying, or any form of harassment.</li></ol></div>
    <div style="margin-top:12pt">Declared this: Day ${esc(f.declaredDay)} Month ${esc(f.declaredMonth)} Year ${esc(f.declaredYear)}</div>
    <div class="signature-line" style="margin-top:12pt">Signature of Deponent: ${esc(f.fullNameWithEnrollmentNo)}</div>
    <div class="static-legal" style="margin-top:12pt"><p style="font-weight:bold">VERIFICATION</p><p>I, ${esc(f.fullNameWithEnrollmentNo)}, the above named deponent, do hereby verify that the contents of the above affidavit are true and correct to the best of my knowledge and belief. No part of it is false and nothing material has been concealed.</p></div>
    <div style="margin-top:12pt">Verified at Place: ${esc(f.verifiedAtPlace)}<br/>On this: Day ${esc(f.verifiedDay)} Month ${esc(f.verifiedMonth)} Year ${esc(f.verifiedYear)}</div>
    <div class="signature-line" style="margin-top:12pt">Signature of Deponent</div>
    <div style="margin-top:24pt;border-top:1px dashed #000;padding-top:12pt"><p style="font-style:italic">Solemnly affirmed and signed in my presence this ___ day of _______ 20__ .</p><div class="signature-line" style="margin-top:24pt">Oath Commissioner</div><p style="font-size:9pt;margin-top:4pt">(This section is for physical notarization only)</p></div>
  </div>`;
}

function renderForm5(d: PrintFormData): string {
  const s = d.student;
  const f = d.form5;
  return `<div class="print-page">
    <div class="header-center"><h1>Shetkari Shikshan Mandal</h1><h2>TSSM's Bhivarabai Sawant College of Engineering &amp; Research, Narhe, Pune</h2><div class="form-title">Library Membership Form — Student</div></div>
    <div class="photo-box" style="width:80pt;height:100pt;padding-top:30pt">Passport Size Photo</div>
    <table>${td("Surname (IN CAPITAL)", f.surname)}${td("First Name", f.firstName)}${td("Father Name (IN CAPITAL)", f.fatherName)}${td("Branch/Department", f.branchDept)}${td("Year", f.yearLevel)}${td("Diploma", f.diplomaFyDsy)}${td("Permanent Address", f.permanentAddress)}${td("City", f.permanentCity)}${td("Pin Code", f.permanentPin)}${td("Local Address", f.localAddress)}${td("City", f.localCity)}${td("Pin Code", f.localPin)}${td("E-Mail ID", f.email)}${td("Date of Birth", f.dateOfBirth)}${td("Gender", f.gender)}${td("Blood Group", f.bloodGroup)}${td("Student Mobile No.", f.studentMobileNo)}${td("Parents Tel. No.", f.parentsTelNo)}${td("Cast Category", f.castCategory)}${td("Admission Receipt No.", f.admissionReceiptNo)}${td("Admission Date", f.admissionDate)}</table>
    <div style="margin-top:16pt" class="signature-line">Signature of Student</div>
    <div style="display:flex;justify-content:space-between;margin-top:12pt"><div>Date: ${esc(f.dateField)}</div><div class="signature-line">Admin Officer/Accountant Sign</div></div>
    <div class="office-use-box" style="margin-top:12pt"><h3>For Library Use Only</h3><div>Membership/I-Card No.: ${esc(f.libraryMembershipIdCardNo)}</div><div>Remark: ${esc(f.remark)}</div><div style="margin-top:8pt;text-align:right" class="signature-line">Librarian Sign</div></div>
  </div>
  <div class="print-page">
    <div class="header-center"><h2>Library Rules &amp; Regulations</h2></div>
    <div class="static-legal"><ol><li>Students must keep the library books and other reading materials neat and clean.</li><li>Books issued must be returned on or before the due date.</li><li>If a book is lost, the student must replace it or pay the cost.</li><li>Library silence must be maintained.</li><li>No food or drink inside the library.</li><li>Students must produce their library card for borrowing books.</li><li>Reference books are not to be taken out of the library.</li><li>Periodicals and newspapers are for reading within the library only.</li><li>Marking, underlining, or damaging library material is strictly prohibited.</li><li>Borrowed books are subject to recall at any time.</li><li>Library cards are non-transferable.</li><li>Students must check the notice board regularly.</li><li>Any violation of rules may result in cancellation of library membership.</li></ol></div>
    <div style="margin-top:12pt"><p><strong>Declaration:</strong> I have read the rules and regulations and ready to follow the same. If any student lost the I-card then I-card will reissue with Rs. 200/- fine.</p></div>
    <div style="display:flex;justify-content:space-between;margin-top:20pt"><div class="signature-line">Signature of Student</div><div>Date: ________</div></div>
  </div>`;
}

export function renderPrintHtml(data: PrintFormData): string {
  return `<!DOCTYPE html>
<html><head>
<meta charset="utf-8"/>
<title>Scholaris — Admission Forms</title>
<style>${PRINT_STYLES}</style>
</head><body>
${renderForm1(data)}
${renderForm2(data)}
${renderForm3(data)}
${renderForm4(data)}
${renderForm5(data)}
</body></html>`;
}
