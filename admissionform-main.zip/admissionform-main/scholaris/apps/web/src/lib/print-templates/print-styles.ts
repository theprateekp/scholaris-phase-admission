export const PRINT_STYLES = `
  @page {
    size: A4;
    margin: 0.75in 0.6in 0.75in 0.6in;
  }
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  body {
    font-family: 'Times New Roman', Times, serif;
    font-size: 11pt;
    line-height: 1.4;
    color: #000;
    background: #fff;
  }
  .print-page {
    page-break-after: always;
    width: 100%;
  }
  .print-page:last-child {
    page-break-after: auto;
  }
  .header-center {
    text-align: center;
    margin-bottom: 12pt;
  }
  .header-center h1 {
    font-size: 14pt;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5pt;
  }
  .header-center h2 {
    font-size: 12pt;
    font-weight: bold;
  }
  .header-center .sub {
    font-size: 10pt;
  }
  .form-title {
    text-align: center;
    font-size: 13pt;
    font-weight: bold;
    text-decoration: underline;
    margin: 8pt 0;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10pt;
    margin: 6pt 0;
  }
  table, th, td {
    border: 1px solid #000;
  }
  th, td {
    padding: 3pt 5pt;
    text-align: left;
    vertical-align: top;
  }
  th {
    font-weight: bold;
    background: #f5f5f5;
  }
  .field-row {
    margin: 4pt 0;
    display: flex;
  }
  .field-label {
    font-weight: bold;
    min-width: 160pt;
  }
  .field-value {
    border-bottom: 1px solid #000;
    min-width: 200pt;
    padding: 0 4pt;
  }
  .signature-line {
    margin-top: 16pt;
    border-top: 1px solid #000;
    width: 200pt;
    padding-top: 2pt;
    font-size: 9pt;
    text-align: center;
  }
  .office-use-box {
    margin-top: 16pt;
    border: 1px solid #000;
    padding: 8pt;
    font-size: 10pt;
  }
  .office-use-box h3 {
    font-size: 11pt;
    text-align: center;
    margin-bottom: 6pt;
  }
  .check-item {
    display: inline-block;
    width: 11pt;
    height: 11pt;
    border: 1px solid #000;
    margin-right: 4pt;
    text-align: center;
    font-size: 9pt;
    line-height: 11pt;
  }
  .check-item.filled::after {
    content: "✓";
  }
  .static-legal {
    font-size: 9.5pt;
    line-height: 1.5;
    margin: 8pt 0;
  }
  .static-legal ol {
    padding-left: 20pt;
  }
  .static-legal li {
    margin: 3pt 0;
  }
  .photo-box {
    width: 100pt;
    height: 120pt;
    border: 1px solid #000;
    float: right;
    margin: 0 0 8pt 8pt;
    text-align: center;
    font-size: 8pt;
    padding-top: 40pt;
  }
  .marks-table th {
    text-align: center;
  }
  .marks-table td {
    text-align: center;
  }
  .checkbox-glyph {
    font-size: 12pt;
  }
  @media print {
    .no-print { display: none; }
  }
`;
