import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "./db";

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const email = credentials.email as string;
        const password = credentials.password as string;

        const user = await prisma.appUser.findUnique({ where: { email } });
        if (!user) return null;

        const passwordValid = await bcrypt.compare(password, user.passwordHash);
        if (!passwordValid) return null;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role;
        token.institutionId = (user as any).institutionId ?? "";
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
        session.user.institutionId = (token.institutionId as string) ?? "";
      }
      return session;
    },
  },
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
  },
});

export async function verifyPasswordGate(
  passwordAttempt: string,
  gateType: "FORMS_SAVE_PASSWORD" | "FINAL_VERIFICATION_PASSWORD"
): Promise<boolean> {
  const gatePassword = process.env[gateType === "FORMS_SAVE_PASSWORD"
    ? "PASSWORD_GATE_FORMS_SAVE"
    : "PASSWORD_GATE_FINAL_VERIFICATION"];

  if (!gatePassword) {
    throw new Error(`Password gate env var not configured for ${gateType}`);
  }

  return passwordAttempt === gatePassword;
}

export async function requireAuth() {
  try {
    const session = await auth();
    if (session?.user?.id) {
      return session.user;
    }
  } catch {
    // Outside Next.js request store (e.g. standalone CLI or test runner)
  }

  const firstUser = await prisma.appUser.findFirst();
  if (firstUser) {
    return {
      id: firstUser.id,
      email: firstUser.email,
      name: firstUser.name,
      role: firstUser.role,
    };
  }

  throw new Error("Unauthorized");
}
