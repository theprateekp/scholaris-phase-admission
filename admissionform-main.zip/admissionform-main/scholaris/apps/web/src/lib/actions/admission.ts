"use server";

import { prisma } from "@/lib/db";
import { requireAuth, verifyPasswordGate } from "@/lib/auth";
import { revalidatePath } from "next/cache";
import { encryptAadharToBuffer } from "@/lib/encryption";

export async function createAdmissionRecord() {
  const user = await requireAuth();
  const institution = await prisma.institution.findFirst();
  if (!institution) throw new Error("No institution configured");

  const record = await prisma.admissionRecord.create({
    data: {
      status: "DRAFT",
      institutionId: institution.id,
      assignedOperatorId: user.id,
      studentProfile: { create: {} },
    },
  });

  try { revalidatePath("/"); } catch {}
  return { id: record.id };
}

function parseDate(val: unknown): Date | null {
  if (!val) return null;
  if (val instanceof Date) return val;
  if (typeof val === "string" && val.trim() !== "") {
    const d = new Date(val);
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
}

function parseIntNullable(val: unknown): number | null {
  if (val === null || val === undefined) return null;
  if (typeof val === "number") return isNaN(val) ? null : Math.round(val);
  if (typeof val === "string") {
    const trimmed = val.trim();
    if (trimmed === "") return null;
    const parsed = parseInt(trimmed, 10);
    return isNaN(parsed) ? null : parsed;
  }
  return null;
}

function parseDecimalNullable(val: unknown): number | string | null {
  if (val === null || val === undefined) return null;
  if (typeof val === "number") return isNaN(val) ? null : val;
  if (typeof val === "string") {
    const trimmed = val.trim();
    return trimmed === "" ? null : trimmed;
  }
  return null;
}

export async function saveFormData(
  recordId: string,
  formKey: "form1" | "form2" | "form3" | "form4" | "form5",
  data: Record<string, unknown>
) {
  const user = await requireAuth();

  const record = await prisma.admissionRecord.findUnique({
    where: { id: recordId },
    select: { status: true },
  });

  if (!record) return { success: false, error: "Record not found" };
  if (record.status !== "DRAFT") {
    return { success: false, error: "Forms can only be edited in DRAFT status" };
  }

  try {
    if (formKey === "form1") {
      const allowedKeys = new Set([
        "admissionQuota", "admissionCategory", "homeUniversity", "motherTongue",
        "sscMarksEnglishObtained", "sscMarksEnglishOutOf", "sscMarksMathsObtained", "sscMarksMathsOutOf",
        "sscGrandTotalObtained", "sscGrandTotalOutOf", "sscPercentage", "sscYearOfPassing",
        "hscPhysicsObtained", "hscPhysicsOutOf", "hscChemistryObtained", "hscChemistryOutOf",
        "hscMathsObtained", "hscMathsOutOf", "hscPcmTotalObtained", "hscPcmTotalOutOf",
        "hscGrandTotalObtained", "hscGrandTotalOutOf", "hscYearOfPassing",
        "cetPhysicsObtained", "cetPhysicsOutOf", "cetChemistryObtained", "cetChemistryOutOf",
        "cetMathsObtained", "cetMathsOutOf", "cetPcmTotalObtained", "cetPcmTotalOutOf",
        "cetExamSeatNo", "cetMeritNo", "aieeeMarks",
        "diplomaMarksObtained", "diplomaMarksOutOf", "diplomaBranchCourse", "diplomaBteEnrollmentNo", "diplomaYearOfPassing",
        "annualIncomeOfParent", "dateField", "placeField",
        "signatureStudentRef", "signatureParentRef", "officeUseEligibleFor", "officeUseBranch"
      ]);

      const intKeys = new Set(["sscYearOfPassing", "hscYearOfPassing", "diplomaYearOfPassing"]);
      const dateKeys = new Set(["dateField"]);
      const decimalKeys = new Set([
        "sscMarksEnglishObtained", "sscMarksEnglishOutOf", "sscMarksMathsObtained", "sscMarksMathsOutOf",
        "sscGrandTotalObtained", "sscGrandTotalOutOf", "sscPercentage",
        "hscPhysicsObtained", "hscPhysicsOutOf", "hscChemistryObtained", "hscChemistryOutOf",
        "hscMathsObtained", "hscMathsOutOf", "hscPcmTotalObtained", "hscPcmTotalOutOf",
        "hscGrandTotalObtained", "hscGrandTotalOutOf",
        "cetPhysicsObtained", "cetPhysicsOutOf", "cetChemistryObtained", "cetChemistryOutOf",
        "cetMathsObtained", "cetMathsOutOf", "cetPcmTotalObtained", "cetPcmTotalOutOf",
        "diplomaMarksObtained", "diplomaMarksOutOf", "annualIncomeOfParent"
      ]);

      const payload: Record<string, unknown> = { admissionRecordId: recordId };
      for (const [k, v] of Object.entries(data)) {
        if (allowedKeys.has(k) && v !== undefined) {
          if (dateKeys.has(k)) {
            payload[k] = parseDate(v);
          } else if (intKeys.has(k)) {
            payload[k] = parseIntNullable(v);
          } else if (decimalKeys.has(k)) {
            payload[k] = parseDecimalNullable(v);
          } else {
            payload[k] = v === "" ? null : v;
          }
        }
      }

      await prisma.form1Application.upsert({
        where: { admissionRecordId: recordId },
        create: payload as any,
        update: payload as any,
      });
    } else if (formKey === "form2") {
      const allowedKeys = new Set([
        "admissionType", "capId", "staffSignRef", "studentSignRef", "checklistDate"
      ]);

      const payload: Record<string, unknown> = { admissionRecordId: recordId };
      for (const [k, v] of Object.entries(data)) {
        if (allowedKeys.has(k) && v !== undefined) {
          if (k === "checklistDate") payload[k] = parseDate(v);
          else payload[k] = v === "" ? null : v;
        }
      }

      await prisma.form2DocumentChecklist.upsert({
        where: { admissionRecordId: recordId },
        create: payload as any,
        update: payload as any,
      });
    } else if (formKey === "form3") {
      const allowedKeys = new Set([
        "courseName", "courseYear", "applicantType", "nationality", "religion",
        "categoryTick", "belongsToReservedYn", "physicallyDisabledYn", "physicallyDisabledType",
        "qualCourseName", "qualDuration", "qualUniversity", "qualCollegeDept",
        "qualSeatNo", "qualMonthYearPassing", "qualPercentage", "qualClassGrade",
        "minorityYn", "minorityLinguistic", "minorityReligion", "signatureCandidateRef",
        "officeReceiptNo", "officeDate", "officeEligibleStatus", "officeAsst", "officeSrAsst", "officeOsRegistrarHod"
      ]);

      const payload: Record<string, unknown> = { admissionRecordId: recordId };
      for (const [k, v] of Object.entries(data)) {
        if (allowedKeys.has(k) && v !== undefined) {
          if (k === "officeDate") payload[k] = parseDate(v);
          else if (k === "qualPercentage") payload[k] = parseDecimalNullable(v);
          else payload[k] = v === "" ? null : v;
        }
      }

      await prisma.form3Eligibility.upsert({
        where: { admissionRecordId: recordId },
        create: payload as any,
        update: payload as any,
      });

      if (data.gapLastExamName) {
        const existingGap = await prisma.educationalGap.findFirst({
          where: { admissionRecordId: recordId }
        });
        const gapData = {
          admissionRecordId: recordId,
          lastExamName: String(data.gapLastExamName),
          seatNo: data.gapSeatNo ? String(data.gapSeatNo) : null,
          monthYearPassing: data.gapMonthYearPassing ? String(data.gapMonthYearPassing) : null,
          percentage: data.gapPercentage ? Number(data.gapPercentage) : null,
          classGrade: data.gapClassGrade ? String(data.gapClassGrade) : null,
        };

        if (existingGap) {
          await prisma.educationalGap.update({
            where: { id: existingGap.id },
            data: gapData,
          });
        } else {
          await prisma.educationalGap.create({
            data: gapData,
          });
        }
      }
    } else if (formKey === "form4") {
      const allowedKeys = new Set([
        "fullNameWithEnrollmentNo", "sonDaughterOf", "admittedToInstitution",
        "declaredDay", "declaredMonth", "declaredYear", "signatureDeponentRef",
        "verifiedAtPlace", "verifiedDay", "verifiedMonth", "verifiedYear",
        "signatureDeponentVerificationRef"
      ]);

      const payload: Record<string, unknown> = { admissionRecordId: recordId };
      for (const [k, v] of Object.entries(data)) {
        if (allowedKeys.has(k) && v !== undefined) {
          payload[k] = v === "" ? null : v;
        }
      }

      await prisma.form4AntiRaggingAffidavit.upsert({
        where: { admissionRecordId: recordId },
        create: payload as any,
        update: payload as any,
      });
    } else if (formKey === "form5") {
      const allowedKeys = new Set([
        "yearLevel", "diplomaFyDsy", "localAddress", "localCity", "localPin",
        "castCategory", "librarySignatureRef", "dateField", "adminOfficerAccountantSignRef",
        "libraryMembershipIdCardNo", "remark", "librarianSignRef", "rulesAgreedYn", "rulesAgreedAt"
      ]);

      const payload: Record<string, unknown> = { admissionRecordId: recordId };
      for (const [k, v] of Object.entries(data)) {
        if (allowedKeys.has(k) && v !== undefined) {
          if (k === "dateField" || k === "rulesAgreedAt") payload[k] = parseDate(v);
          else payload[k] = v === "" ? null : v;
        }
      }

      await prisma.form5LibraryMembership.upsert({
        where: { admissionRecordId: recordId },
        create: payload as any,
        update: payload as any,
      });
    }

    return { success: true };
  } catch (err: any) {
    console.error(`Error in saveFormData (${formKey}):`, err);
    return { success: false, error: err.message || "Failed to save form data" };
  }
}

export async function saveChecklistItems(
  recordId: string,
  items: { srNo: number; documentName: string; required: boolean }[]
) {
  await requireAuth();

  try {
    await prisma.form2DocumentChecklist.upsert({
      where: { admissionRecordId: recordId },
      create: { admissionRecordId: recordId },
      update: {},
    });

    for (const item of items) {
      await prisma.checklistItem.upsert({
        where: { form2Id_srNo: { form2Id: recordId, srNo: item.srNo } },
        create: {
          form2Id: recordId,
          srNo: item.srNo,
          documentName: item.documentName,
          required: item.required,
        },
        update: {
          required: item.required,
        },
      });
    }

    return { success: true };
  } catch (err: any) {
    console.error("Error in saveChecklistItems:", err);
    return { success: false, error: err.message || "Failed to save checklist items" };
  }
}

export async function verifyFormsPassword(
  recordId: string,
  passwordAttempt: string
) {
  const user = await requireAuth();
  const valid = await verifyPasswordGate(passwordAttempt, "FORMS_SAVE_PASSWORD");

  await prisma.verificationLog.create({
    data: {
      admissionRecordId: recordId,
      action: "FORMS_SAVE_PASSWORD",
      actorId: user.id,
      roleAtTime: String(user.role),
      passwordConfirmed: valid,
    },
  });

  if (!valid) {
    return { success: false, error: "Incorrect password" };
  }

  await prisma.admissionRecord.update({
    where: { id: recordId },
    data: { status: "FORMS_COMPLETE" },
  });

  try { revalidatePath("/"); } catch {}
  return { success: true };
}

export async function updateStudentProfile(
  recordId: string,
  data: Record<string, unknown>
) {
  await requireAuth();

  const record = await prisma.admissionRecord.findUnique({
    where: { id: recordId },
    select: { status: true },
  });

  if (!record) return { success: false, error: "Record not found" };
  if (record.status !== "DRAFT") {
    return { success: false, error: "Profile can only be edited in DRAFT status" };
  }

  try {
    const allowedKeys = new Set([
      "fullNameSurname", "fullNameFirst", "fullNameFather", "fatherName", "motherName",
      "dateOfBirth", "gender", "bloodGroup", "mobileNo", "contactTelNo", "parentsTelNo",
      "email", "religionCaste", "category", "branchCourse", "admissionYearStart",
      "admissionYearEnd", "admissionDate", "correspondenceAddress", "correspondencePin",
      "correspondenceTelNo", "permanentAddress", "permanentPin", "permanentCity",
      "permanentTelNo", "panNo", "photoFileRef", "admissionReceiptNo", "aadharNoEncrypted"
    ]);

    const intKeys = new Set(["admissionYearStart", "admissionYearEnd"]);
    const dateKeys = new Set(["dateOfBirth", "admissionDate"]);

    const payload: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(data)) {
      if (k === "aadharNo" && typeof v === "string" && v.trim() !== "") {
        payload.aadharNoEncrypted = encryptAadharToBuffer(v);
      } else if (allowedKeys.has(k) && v !== undefined) {
        if (dateKeys.has(k)) {
          payload[k] = parseDate(v);
        } else if (intKeys.has(k)) {
          payload[k] = parseIntNullable(v);
        } else {
          payload[k] = v === "" ? null : v;
        }
      }
    }

    await prisma.studentProfile.upsert({
      where: { admissionRecordId: recordId },
      create: { admissionRecordId: recordId, ...payload } as any,
      update: payload as any,
    });

    return { success: true };
  } catch (err: any) {
    console.error("Error in updateStudentProfile:", err);
    return { success: false, error: err.message || "Failed to update student profile" };
  }
}

export async function getAdmissionRecord(recordId: string) {
  await requireAuth();

  const record = await prisma.admissionRecord.findUnique({
    where: { id: recordId },
    include: {
      studentProfile: true,
      form1Application: true,
      form2Checklist: { include: { items: { orderBy: { srNo: "asc" } } } },
      form3Eligibility: { include: { educationalGaps: true } },
      form4Affidavit: true,
      form5Library: true,
    },
  });

  return record;
}
