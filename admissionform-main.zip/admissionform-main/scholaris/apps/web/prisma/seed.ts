import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import bcrypt from "bcryptjs";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

async function main() {
  // Clean existing data for idempotent seed
  await prisma.admissionRecord.deleteMany();
  await prisma.appUser.deleteMany();
  await prisma.institution.deleteMany();
  
  const institution = await prisma.institution.create({
    data: {
      name: "TSSM's Bhivarabai Sawant College of Engineering & Research",
      address: "Narhe, Pune, Maharashtra",
      phone: "020-24301234",
      website: "https://bscoer.edu.in",
    },
  });

  const passwordHash = await bcrypt.hash("admin@123", 12);

  await prisma.appUser.createMany({
    data: [
      {
        name: "Front Desk Admin",
        email: "frontdesk@bscoer.edu.in",
        passwordHash,
        role: "FrontDesk",
      },
      {
        name: "Verification Admin",
        email: "verification@bscoer.edu.in",
        passwordHash,
        role: "VerificationAdmin",
      },
      {
        name: "Higher Authority",
        email: "hod@bscoer.edu.in",
        passwordHash,
        role: "HigherAuthority",
      },
      {
        name: "System Admin",
        email: "admin@bscoer.edu.in",
        passwordHash,
        role: "SystemAdmin",
      },
    ],
  });

  console.log("Seed complete. Institution:", institution.id);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
