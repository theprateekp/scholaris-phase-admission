# Business Rules Reference
## Scholaris — Admission Module (Phase 1)

This document is the single source of truth for cross-cutting rules referenced but not fully spelled out elsewhere (`04_SCHEMA.md` explicitly points here for the category vocabulary union). It also documents field-fidelity gaps found while auditing the schema against the PRD and the five source forms, with corrective additions.

---

## 1. Status Transition Rules

```
DRAFT
  → FORMS_COMPLETE        [gate: Stage-1 password, server-enforced]
  → DOCS_IN_PROGRESS      [auto, on first document upload]
  → DOCS_VERIFIED         [auto, when every REQUIRED checklist slot = VERIFIED]
  → FEE_RECORDED          [on Fee Entry save]
  → READY_TO_PRINT        [on "Approve Preview"]
  → PRINTED               [on Print action; writes PrintLog]
  → PENDING_FINAL_VERIFICATION  [auto, immediately after PRINTED]
  → ADMITTED              [gate: Final Verification password, server-enforced; record locks]

ON_HOLD / REJECTED — may branch off from ANY of the above states.
  - ON_HOLD requires hold_reason (text, mandatory).
  - REJECTED requires rejected_reason (text, mandatory).
  - Both are resumable→ON_HOLD only (REJECTED is terminal, no forward transition).
  - Returning from ON_HOLD restores the record to whatever status it held before pausing.
```

**Rules:**
- No status may be skipped forward (e.g., `DRAFT` cannot jump straight to `FEE_RECORDED`).
- Only `ADMITTED` sets `locked_at`. No other status blocks edits at the application layer.
- A password gate failure never mutates status — the record stays exactly where it was, retry allowed.
- Status changes always write a row to `VerificationLog` (action = `STATUS_CHANGE`) *except* the two password-gated transitions, which use their own dedicated action types (`FORMS_SAVE_PASSWORD`, `FINAL_VERIFICATION_PASSWORD`).

---

## 2. Password Gate Rules

| Gate | Triggers at | Server enforcement | Failure behavior |
|---|---|---|---|
| Forms-save gate | End of Form 5, before `FORMS_COMPLETE` | Server Action validates against stored hash before any DB write | Inline error, retry allowed, **zero** partial persistence |
| Final-verification gate | Higher authority clicks "Verified" in queue | Server Action validates before `ADMITTED` transition + lock | Inline error, retry allowed, record stays `PENDING_FINAL_VERIFICATION` |

- Client-side password state is never trusted — the UI may pre-validate format only (non-empty), never correctness.
- Every attempt (success or failure) writes a `VerificationLog` row with `password_confirmed: true/false`. Repeated failures are not rate-limited in v1 (flagged as a Phase 7 hardening candidate, not a Phase 1 blocker).

---

## 3. Shared-Field Auto-Fetch Rules

- **First writer wins as canonical source.** Whichever of the 5 forms the operator reaches first for a given field becomes `source_form` on `StudentProfile`. All later forms show it pre-filled with a subtle "auto-filled" indicator.
- **Local override never mutates the source.** If a form needs a variant (e.g., ALL CAPS on the Library form), the operator edits that form's local copy only; `StudentProfile`'s canonical value is untouched.
- **No silent loss.** Every propagation event and every local override is logged at the application layer (not `VerificationLog` — a lighter internal change record is sufficient) so a support request of "why does Form 3 show a different DOB than Form 1" is always answerable.
- Full field↔form mapping is PRD §7's table — this doc does not repeat it, only governs the *behavior* around it.

---

## 4. Category Vocabulary Union (resolves the schema's open TODO)

Each source form uses a different, overlapping reservation-category vocabulary. The **canonical union**, stored on `StudentProfile.category`, is:

```
Open, OBC, SBC, SEBC, EWS, DEF, PH, Other,
NT1, NT2, NT3, NT(B), NT(C), NT(D), DT(A), VJ,
SC, ST
```

**Per-form allowed subsets** (the UI must restrict the dropdown to only the subset below on each form, even though the canonical field can hold any union value):

| Form | Allowed values |
|---|---|
| Form 1 (Application) | Open, OBC, SBC, NT1, NT2, NT3, SC, ST, DEF, PH |
| Form 3 (Eligibility) | Open, SC, ST, DT(A), NT(B), NT(C), NT(D), OBC, SBC, SEBC, EWS |
| Form 5 (Library) | Open, SC, ST, VJ, NT1, NT2, NT3, SBC, Other |

**Reconciliation rule:** since `NT1`/`NT2`/`NT3` (Form 1 / Form 5 spelling) and `NT(B)`/`NT(C)`/`NT(D)` (Form 3 spelling) refer to the same real-world categories under different SPPU-vs-college labeling conventions, treat them as **display aliases of the same canonical value** rather than distinct categories — map `NT1↔NT(B)`, `NT2↔NT(C)`, `NT3↔NT(D)` when propagating between Form 1/5 and Form 3. This mapping must live in code (`lib/rules/category-aliases.ts` or equivalent), not just in this doc.

**Conditional-document rule:** Form 2 checklist rows 10–15 (Cast Certificate, Cast Validity Certificate, Non Creamy-layer, Income Certificate, EWS Certificate, Gap Certificate) should only auto-tick "required" when `StudentProfile.category` is a reserved category (i.e., not `Open`) — this is a recommended UX default the operator can still override, not a hard system lock.

---

## 5. Document Checklist & Verification Rules

- Upload slots are generated **only** for Form 2 rows ticked `required = true`. `N/A`-ticked rows never generate a slot, hidden not just disabled.
- **Two-layer check, both required before a slot counts as complete:**
  1. System auto-check (file integrity, non-blank, correct MIME type) — runs immediately on upload, is informational, never blocks the admin from proceeding to manual review even if it flags an issue.
  2. Admin manual check — `Received: Yes/No` tick, then a separate `Verified` click. **Upload ≠ Verified**; these are always two distinct actions, never merged into one button.
- Slot lifecycle: `NOT_UPLOADED → UPLOADED_PENDING_REVIEW → VERIFIED` (or `REJECTED_REUPLOAD`, which loops back to `NOT_UPLOADED`).
- `DOCS_VERIFIED` status is reached automatically, the instant the last required slot flips to `VERIFIED` — no manual "complete stage" button.
- File types accepted: JPG, PNG, PDF only. Server re-validates MIME type from file bytes, never trusts the client-reported `Content-Type` or file extension.

---

## 6. Fee Module Rules

- `remaining_balance = total_fee_amount - amount_paid` (recomputed on every save, never manually entered).
- `fee_status` is fully derived, never set directly:
  - `amount_paid = 0` → `Unpaid`
  - `0 < amount_paid < total_fee_amount` → `Partially_Paid`
  - `amount_paid >= total_fee_amount` → `Fully_Paid`
- Installment rows are append-only once `installment_enabled = true`; `installment_no` auto-increments per record and is never reused, even if an installment is later voided (void via a `voided` flag, not deletion — keeps the append-only audit spirit consistent with `VerificationLog`).
- `remaining_after` on each installment row is a point-in-time snapshot, not recalculated retroactively if an earlier installment is edited — installments are corrected by adding a new offsetting row, never by mutating history.

---

## 7. Print Fidelity Rules

- The preview template and the print template are **the same template** — there is never a separate "what the admin sees" vs "what gets printed" render. Any visual drift between preview and print is a bug, not an acceptable inconsistency.
- Static legal/reference text (Anti-Ragging clauses, Library Rules & Regulations, Annexure 'A' Eligibility Fee table, the SPPU attached-certificates reference list) is reproduced **verbatim** from the source PDFs — same numbering, same paragraph breaks, non-editable in the UI, not sourced from a paraphrase.
- Signature lines always render as blank underlines in v1, even for records where a digital signature capture might exist later — wet-ink signing is the standing assumption (PRD §14, open question 1) until explicitly overturned.
- The Oath Commissioner section (Form 4) and any notarization block render as blank static space only — no digital fields feed it, ever.
- A physical print-vs-scan comparison pass is a **blocking QA gate** before go-live (already tracked in `06_TRACKER.md` item 2.9) — no code change should be considered "done" for the print engine until this manual check passes.

---

## 8. Security & Audit Rules

- `aadhar_no` (Form 3 / `StudentProfile`) and the APAAR/ABC ID document reference are encrypted at rest and masked in the UI by default; unmasking is an explicit, logged admin action.
- `VerificationLog` is append-only — no `UPDATE` or `DELETE` statements are ever issued against it at the application layer, enforced by DB permissions if possible (a dedicated low-privilege role for the app's DB user, with no `DELETE`/`UPDATE` grant on that table).
- A record's `locked_at` (set on `ADMITTED`) blocks all writes to that record's forms, documents, and fee tables at the application layer — any post-admission correction requires an explicit `UNLOCK` action, itself logged, per PRD §14 open question 5 (pending stakeholder confirmation — do not build silent-edit paths around the lock in the meantime).

---

## 9. Field-Fidelity Corrections (gap analysis vs. source PDFs)

The following fields exist on the physical forms but were missing from `04_SCHEMA.md`. Add them before Phase 1 sign-off, since PRD Goal G1 requires 100% field fidelity:

| Missing field | Belongs on | Source |
|---|---|---|
| `contact_tel_no` (general STD landline, Form 1 item 8 — distinct from `mobile_no`) | `StudentProfile` | Form 1, item 8 |
| `correspondence_tel_no` (STD landline for correspondence address) | `StudentProfile` | Form 1, item 16 |
| `permanent_tel_no` (STD landline for permanent address) | `StudentProfile` | Form 1, item 17 |
| `permanent_city` (City field, separate from the address text) | `StudentProfile` | Library form, item 5 |
| `admission_date` (Form 5 item 14 — distinct from `admission_receipt_no`) | `StudentProfile` | Library form, item 14 |
| `admin_officer_accountant_sign_ref` + form-level `date_field` | `Form5LibraryMembership` | Library form (Date + Admin. Officer/Accountant Sign. line) |

None of these are sensitive fields (no encryption implications) — they're plain text/date additions to existing tables.

---

## 10. Multi-Tenancy Readiness Rules (even though v1 is single-tenant)

- No form-specific field name, label, or category vocabulary may be hardcoded into UI components — everything routes through the Zod schema + this rules doc's mappings, keyed by `institution_id`.
- The category-alias mapping (§4) and conditional-document mapping (§4) are treated as **tenant-scoped configuration**, not global constants, even though v1 seeds only one tenant's values.
