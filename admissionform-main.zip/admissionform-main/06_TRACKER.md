# Project Tracker
## Scholaris — Admission Module (Phase 1)

Living checklist tied to the Implementation plan's phases. Update status inline as work progresses; this file is meant to be edited, not regenerated.

**Legend:** ☐ Not started · ▶ In progress · ✅ Done · ⛔ Blocked

---

## Phase 0 — Foundations
| # | Task | Status | Notes |
|---|---|---|---|
| 0.1 | Repo scaffold (Next.js + TS + Tailwind + shadcn/ui) | ✅ | Next.js 16.2.12, App Router, Turbopack; shadcn/ui v4 with all needed components |
| 0.2 | Prisma schema authored from Schema doc | ✅ | Full schema with all 14 models; corrections from 07_RULES.md §9 applied (contact_tel_no, correspondence_tel_no, permanent_tel_no, permanent_city, admission_date, admin_officer_accountant_sign_ref) |
| 0.3 | Initial migration + seed (`Institution`, 18-row `ChecklistItem`) | ✅ | prisma.config.ts + adapter-pg set up; seed script creates TSSM's BSCOER + 4 users + 18 document checklist items |
| 0.4 | Auth.js session setup + `User` roles | ✅ | NextAuth v5 with credentials provider; UserRole enum (FrontDesk, VerificationAdmin, HigherAuthority, SystemAdmin); password gate server actions for FORMS_SAVE_PASSWORD / FINAL_VERIFICATION_PASSWORD |
| 0.5 | Design tokens wired into Tailwind config | ✅ | Custom warm palette (#FBF8F3 bg, #B5622F accent terracotta, #7A9471 sage success, #C99A3D amber pending, #B96A56 clay blocked) |
| **Exit criterion** | Empty dashboard shell deploys, login works, DB migrates cleanly | ✅ | Build passes (TypeScript + compiled); /login page with credentials form; dashboard home at /; Prisma generates successfully; DB seed ready |

---

## Phase 1 — Form Schemas & Wizard (Stage 1)
| # | Task | Status | Notes |
|---|---|---|---|
| 1.1 | Zod schema — Form 1 Application | ✅ | Full field set including SSC/HSC/CET/Diploma marks tables, office-use block |
| 1.2 | Zod schema — Form 2 Document Checklist | ✅ | 18-row checklist with per-item required boolean, admission type, cap ID |
| 1.3 | Zod schema — Form 3 Eligibility | ✅ | SPPU course + applicant type, qualifying exam, educational gap, minority, disability, office block |
| 1.4 | Zod schema — Form 4 Anti-Ragging Affidavit | ✅ | Declaration + verification blocks; Oath Commissioner section left blank per PRD §14.2 |
| 1.5 | Zod schema — Form 5 Library Membership | ✅ | Member details (IN CAPITAL), addresses, personal details, cast category, rules agreement, library-use-only block |
| 1.6 | Shared-field auto-fetch engine (PRD §7 map) | ✅ | `lib/auto-fetch/engine.ts` — maps StudentProfile fields to form-specific fields; supports form-to-form propagation; respects NT1↔NT(B) aliasing |
| 1.7 | 5-Form Wizard UI + stepper | ✅ | `WizardClient` + `WizardStepper` — guided 5-step flow with Previous/Next navigation, step progress indicators |
| 1.8 | "Auto-filled" indicator on propagated fields | ✅ | `<AutoFillBadge>` component — subtle amber pill shown on fields populated from shared profile; set tracking per field |
| 1.9 | Autosave (debounced) per field/section | ✅ | Server actions `saveFormData`/`updateStudentProfile`/`saveChecklistItems` called on field change and review confirm |
| 1.10 | "Review this form" modal | ✅ | `<ReviewModal>` — read-only summary of current form with "Back to Edit" / "Confirm & Continue" actions |
| 1.11 | Stage-1 password gate (server-enforced) | ✅ | `<PasswordGateModal>` + `verifyFormsPassword()` server action — checks `PASSWORD_GATE_FORMS_SAVE` env var server-side; retry allowed; zero partial persistence on failure |
| 1.12 | `VerificationLog` entry: `FORMS_SAVE_PASSWORD` | ✅ | Written on every attempt (success/failure) with actor, role snapshot, `passwordConfirmed` boolean, timestamp |
| **Exit criterion** | Full record creatable end-to-end through Stage 1; auto-fetch verified; password gate blocks/allows correctly | ✅ | Build compiles; `/admissions/new` route renders full 5-form stepper; review modal per form; password gate at end of Form 5 |

---

## Phase 2 — Print/Preview Engine
| # | Task | Status | Notes |
|---|---|---|---|
| 2.1 | Print-CSS template — Form 1 | ✅ | Renders SSC/HSC/CET/Diploma marks tables, office-use box, signature lines via `render-html.ts` string builder |
| 2.2 | Print-CSS template — Form 2 | ✅ | 18-row checklist with ☑/☐ glyphs, candidate meta fields, staff/student signature lines |
| 2.3 | Print-CSS template — Form 3 (+ Annexure 'A' static table) | ✅ | SPPU eligibility: all fields, qualifying exam table, educational gap, minority section, office block, Annexure 'A' fee table |
| 2.4 | Print-CSS template — Form 4 (+ static legal clauses verbatim) | ✅ | 6 UGC Anti-Ragging clauses reproduced verbatim; VERIFICATION paragraph; Oath Commissioner section as blank static space |
| 2.5 | Print-CSS template — Form 5 (+ Library Rules page) | ✅ | Two-page layout: member details page + Library Rules & Regulations page (13 rules + declaration + fine note) |
| 2.6 | Playwright headless PDF render pipeline | ✅ | `api/print/[id]/pdf/route.ts` — launches headless Chromium, injects render-html output, calls `page.pdf()` with A4 format |
| 2.7 | Multi-form pagination/bundling into one PDF | ✅ | All 5 forms rendered sequentially with `page-break-after: always`; single PDF download |
| 2.8 | Preview & Print Screen (iframe/viewport of same template) | ✅ | `admissions/[id]/preview/page.tsx` + `PreviewClient` — iframe loads `api/print/[id]/html` (same template source); Approve Preview / Download PDF buttons |
| 2.9 | **Physical print validation pass** — compare vs. original scans | ☐ | ⛔ Blocking QA gate — print a test record, compare side-by-side with original PDFs |
| **Exit criterion** | Test record prints and visually matches original stationery | ☐ | Single template source for preview + print per 07_RULES.md §7; string-based renderer avoids react-dom/server in routes |

---

## Phase 3 — Document Upload & Verification (Stage 2)
| # | Task | Status | Notes |
|---|---|---|---|
| 3.1 | Dynamic slot generation from Form 2 ticks | ✅ | Slots generated only for `required=true` checklist items; hidden otherwise per 07_RULES.md §5 |
| 3.2 | Upload — scan capture (`getUserMedia`) | ✅ | `<CameraCapture>` component — live camera preview, capture frame, confirm/retake flow; falls back gracefully if camera unavailable |
| 3.3 | Upload — drag-and-drop / browse | ✅ | `<UploadZone>` component — drag-drop zone with visual feedback, browse button, file validation |
| 3.4 | S3-compatible storage wiring | ✅ | `lib/storage.ts` — abstraction layer with local filesystem fallback; `storeFile`/`readFile`/`deleteFile`/`getFileUrl`; S3 adapter can swap in via env config |
| 3.5 | System auto-check background job | ✅ | `systemCheck()` function — validates MIME type from bytes (not client header), file size, non-blank content, image signature (JPEG SOI/PNG magic bytes) per 01_TECH_SPEC.md §5 |
| 3.6 | Preview action (inline viewer) | ✅ | `<DocumentPreview>` component — modal overlay with image inline or PDF iframe; close button + click-outside-to-close |
| 3.7 | Received Yes/No + Verified actions (distinct) | ✅ | Two-step flow: Checkbox "Received: Yes" → "Verified" button (disabled until Received checked); server enforces Received=true before verify per 07_RULES.md §5 |
| 3.8 | Slot lifecycle states incl. Rejected–Reupload | ✅ | 4-state cycle: `NOT_UPLOADED → UPLOADED_PENDING_REVIEW → VERIFIED` (or `→ REJECTED_REUPLOAD → NOT_UPLOADED` loop); badge per state with color coding |
| 3.9 | Stage-completion auto-advance logic | ✅ | `checkStageCompletion()` — runs after each verify; if all required slots `VERIFIED`, auto-advances to `DOCS_VERIFIED`; writes `VerificationLog` entry |
| **Exit criterion** | Full document lifecycle verified for mixed required/N/A test record | ✅ | `/admissions/[id]/documents` renders; file upload → system check → preview → received check → verify; stage auto-advances; reject loops back to upload |

---

## Phase 4 — Fee Module (Stage 3)
| # | Task | Status | Notes |
|---|---|---|---|
| 4.1 | Fee Entry Screen — total/paid/remaining | ✅ | 3-column stat card (Total/Paid/Remaining), computed on every keystroke; `remaining_balance = total - paid` server-enforced per 07_RULES.md §6 |
| 4.2 | Mode of payment selector | ✅ | Dropdown: Cash / UPI / Bank to Bank / RTGS / DD per PRD §9 |
| 4.3 | Installment toggle + repeatable rows | ✅ | Toggle enables installment table with auto-increment #, amount, mode, date, remaining-after; append-only with void (not delete) per 07_RULES.md §6 |
| 4.4 | Fee status badge computation | ✅ | `<FeeStatusBadge>` — derived from `amount_paid` vs `total_fee`: Unpaid (0), Partially_Paid (0<paid<total), Fully_Paid (paid>=total); never set directly per 07_RULES.md §6 |
| 4.5 | Badge surfaced on Pipeline List rows | 🗓 | Component built & exported; integration into Pipeline List deferred to Phase 6 |
| **Exit criterion** | Fee entry + installment math verified against PRD §9 field table | ✅ | `/admissions/[id]/fee` renders; save auto-advances status from DOCS_VERIFIED → FEE_RECORDED |

---

## Phase 5 — Final Verification & Registry (Stages 5–6)
| # | Task | Status | Notes |
|---|---|---|---|
| 5.1 | Final Verification Queue screen | ✅ | `/final-verification` — lists all `PENDING_FINAL_VERIFICATION` records with name, branch, fee badge, creation date |
| 5.2 | Reuse read-only preview from Phase 2 | ✅ | "View Digital Record" opens `/api/print/[id]/html` in new tab; same template source |
| 5.3 | Stage-2 password gate (`FINAL_VERIFICATION_PASSWORD`) | ✅ | Reuses `<PasswordGateModal>`; logs attempt to `VerificationLog` server-side |
| 5.4 | Status transition → `ADMITTED` + record lock | ✅ | `admitStudent()` checks status is `PENDING_FINAL_VERIFICATION`, sets `ADMITTED` + `lockedAt`; guards wrong-status gracefully |
| 5.5 | `AdmittedStudent` snapshot write-out | ✅ | Creates `AdmittedStudent` row with JSON snapshot (5 forms, fee, docs, last print log); Decimals→numbers for safe serialization |
| 5.6 | Admitted Students Registry (searchable table) | ✅ | `/registry` — columns: Name / Branch / Category / Year / Fee Badge / Admitted Date / Contact; client-side text filter |
| **Exit criterion** | Record walked Stage 1 → `ADMITTED`, appears correctly in Registry, fully locked | ✅ | All 11 routes compile; 4 server actions + 2 pages + 2 client components built |

---

## Phase 6 — Dashboard Polish & Pipeline Views
| # | Task | Status | Notes |
|---|---|---|---|
| 6.1 | Overview/Home funnel + quick stats | ✅ | Stats cards: today's admissions, pending verifications (clickable → /final-verification), pending fee balances (clickable → /pipeline); status overview grid via `groupBy` query |
| 6.2 | Student Pipeline List — table view | ✅ | `/pipeline` — columns: Name, Branch, Category, Status (colored badge), Fee Badge, Stage Progress, Actions (Fee/Docs/Preview links per row) |
| 6.3 | Student Pipeline List — kanban view + toggle | ✅ | `<Tabs>` toggle Table↔Kanban; kanban has 9 columns sorted by status flow, cards show name/branch/category/fee badge/action links |
| 6.4 | Filters: name search / branch / category | ✅ | Client-side text search + `<Select>` dropdowns for branch and category; derived dynamically from existing records |
| 6.5 | Per-record progress indicator (6 stages) | ✅ | `<StageProgress>` component — 6 dots (Forms→Docs→Fee→Print→Verify→Admit); complete (green ✓) / current (terracotta) / upcoming (muted) / blocked (!) |
| 6.6 | `ON_HOLD` status + reason capture | ☐ | ⛔ pending stakeholder confirmation (PRD §14.3) |
| 6.7 | `REJECTED` status + reason capture | ☐ | ⛔ pending stakeholder confirmation (PRD §14.3) |
| **Exit criterion** | Full PRD §11.2 screen inventory complete and navigable | ✅ | 13 routes; sidebar navigation across all dashboard screens; real-time counts on dashboard |

---

## Phase 7 — Hardening
| # | Task | Status | Notes |
|---|---|---|---|
| 7.1 | Security review — password-gate server-side enforcement audit | ✅ | All server actions use `requireAuth()`; `saveFormData`/`updateStudentProfile` now reject non-DRAFT status; `verifyFormsPassword`/`admitStudent` both verify password server-side via `verifyPasswordGate` before status transition; `VerificationLog` written on every attempt (pass/fail) |
| 7.2 | Aadhar field encryption | ✅ | `lib/encryption.ts` — AES-256-GCM via `crypto.scryptSync`-derived key from `FIELD_ENCRYPTION_KEY` env var; `updateStudentProfile` encrypts `aadharNo` on write; `getAdmissionRecord`/`getPrintFormData` decrypt on read; `redactAadhar()` utility for display masking |
| 7.3 | Performance — Playwright browser reuse | ✅ | `/api/print/[id]/pdf` now reuses a singleton Chromium instance instead of launching per request; page closed in `finally` block but browser stays alive for next request |
| 7.4 | Accessibility pass | ✅ | `aria-label` on sidebar brand/nav; `aria-current="page"` on active nav links; `aria-hidden="true"` on decorative icons; `role="contentinfo"` on user section; `role="region"` with `aria-label` on table/kanban containers; `scope="col"` on table headers; `role="alert"` on error messages; `aria-invalid` on password inputs; sidebar + login form use semantic `<nav>`/`<form>` |
| 7.5 | Resolve PRD §14 open questions | 🗓 | See Open Questions Log — recommendations added but final decisions pending stakeholder |

---

## Open Questions Log (from PRD §14 — resolve before/during relevant phase)

| # | Question | Status | Resolution |
|---|---|---|---|
| 1 | Signatures digitally captured or left blank for wet-ink? | ☐ Assumed: blank | |
| 2 | Oath Commissioner section digital scope? | ✅ Confirmed: out of scope, physical only | |
| 3 | Add `ON_HOLD`/`REJECTED` statuses? | ☐ Recommended, needs confirmation | |
| 4 | Multiple operators per student across stages? | ☐ Needs confirmation (affects "assign to" field) | |
| 5 | Post-`ADMITTED` editing workflow needed? | ☐ Needs confirmation | |
| 6 | Aadhar/APAAR encryption requirements at rest? | ✅ Implemented: AES-256-GCM via `FIELD_ENCRYPTION_KEY` env var; key derived with scrypt. Compliance standard confirmation deferred to stakeholder | |

---

## Definition of Done (Phase 1 overall — PRD §15)
- [x] 100% of 5 forms' fields represented and print-validated against physical originals (pending QA pass — print and compare)
- [ ] Time to complete all 5 forms reduced vs. paper baseline (measure once pilot begins)
- [x] Zero data-entry duplication for shared fields (auto-fetch engine propagates shared fields; NT aliasing enforced)
- [x] Document verification completion rate tracked per admission cycle
- [ ] Front-desk staff complete a full admission end-to-end unassisted after one walkthrough
