# Implementation Plan
## Scholaris — Admission Module (Phase 1)

Phased build plan translating the Tech Spec, App Flow, Design, and Schema docs into shippable increments. Ordered so every phase produces something demoable, and so the hardest risk (print fidelity) is de-risked early rather than left for the end.

---

## 1. Suggested Project Structure

```
scholaris/
├─ apps/
│  └─ web/                      # Next.js 15 app (App Router)
│     ├─ app/
│     │  ├─ (dashboard)/
│     │  │  ├─ page.tsx                     # Overview / Home
│     │  │  ├─ pipeline/                    # Student Pipeline List
│     │  │  ├─ admissions/new/              # 5-Form Wizard
│     │  │  ├─ admissions/[id]/
│     │  │  │  ├─ documents/                # Document Verification Workspace
│     │  │  │  ├─ fee/                      # Fee Entry Screen
│     │  │  │  ├─ preview/                  # Preview & Print Screen
│     │  │  │  └─ page.tsx                  # Record Detail / Stage Overview
│     │  │  ├─ final-verification/          # Final Verification Queue
│     │  │  └─ registry/                    # Admitted Students Registry
│     │  └─ api/
│     │     ├─ print/[id]/route.ts          # Playwright PDF render endpoint
│     │     └─ webhooks/
│     ├─ components/                        # shadcn/ui-based components
│     ├─ lib/
│     │  ├─ forms/                          # Zod schemas, one per form (data-driven, §4 Tech Spec)
│     │  ├─ auto-fetch/                     # Shared-field propagation engine (PRD §7)
│     │  ├─ print-templates/                # Print-CSS HTML templates, 1:1 with Zod schemas
│     │  └─ auth/                           # Session + password-gate server actions
│     └─ prisma/
│        └─ schema.prisma
├─ packages/
│  └─ config/                   # Shared design tokens, eslint, tsconfig
└─ tests/
   ├─ unit/
   └─ e2e/                      # Playwright, includes print-fidelity snapshot tests
```

---

## 2. Phase Plan

### Phase 0 — Foundations (pre-work)
- Repo scaffold (Next.js + TypeScript + Tailwind + shadcn/ui).
- Prisma schema from the Schema doc; initial migration; seed script for `Institution` (this college) and the 18-row `ChecklistItem` reference list.
- Auth.js session setup + `User` roles (even if Phase 1 UI doesn't branch by role yet).
- Design tokens (colors/typography/spacing from Design doc) wired into Tailwind config.

**Exit criterion:** empty dashboard shell deploys, login works, DB migrates cleanly.

---

### Phase 1 — Form Schemas & Wizard (Stage 1)
1. Build Zod schema for each of the 5 forms (field lists from Schema doc §2.3–2.7).
2. Build the shared-field auto-fetch engine: on any `StudentProfile` field write, propagate to all forms per the map in PRD §7; track `source_form` per field.
3. Build the 5-Form Wizard UI: stepper, per-form screens, "auto-filled" indicator, autosave (debounced server action per field/section).
4. Build the "Review this form" modal (read-only summary).
5. Build the password-gate modal + server-side enforced check for the Stage 1 completion gate; write the first `VerificationLog` entry type (`FORMS_SAVE_PASSWORD`).

**Exit criterion:** operator can create a full Admission Record end-to-end through Stage 1, data persists, auto-fetch demonstrably works across forms, password gate blocks/allows correctly.

---

### Phase 2 — Print/Preview Engine (de-risk early)
> Pulled forward deliberately — this is the highest-uncertainty piece of the whole project (byte-for-byte fidelity requirement, PRD §10) and should not be discovered late.

1. Build print-CSS HTML templates for all 5 forms (Design doc §6), consuming the same Zod schemas as the wizard.
2. Wire Playwright headless rendering → PDF, bundling all 5 forms paginated in order.
3. Build the Preview & Print Screen as an iframe/viewport rendering the same template.
4. **Physical print validation pass:** print a test record, compare against the original stationery scans (the 5 uploaded PDFs), adjust margins/fonts/table spacing until visually matching.

**Exit criterion:** a filled test record prints and visually matches the original forms closely enough to pass a side-by-side check by someone familiar with the paper originals.

---

### Phase 3 — Document Upload & Verification (Stage 2)
1. Build the Document Verification Workspace: dynamic slot generation from Form 2's ticked checklist.
2. Implement upload (scan capture via `getUserMedia`, drag-and-drop, browse) → S3-compatible storage.
3. Implement system auto-check (file integrity/format/non-blank) as a background job triggered on upload.
4. Implement Preview action + manual Received/Verified actions, with the 4-state slot lifecycle.
5. Stage-completion logic: auto-advance to `DOCS_VERIFIED` when all required slots verified.

**Exit criterion:** full document lifecycle works for a test record with a mix of required/N/A documents.

---

### Phase 4 — Fee Module (Stage 3)
1. Fee Entry Screen: total/paid/remaining, mode of payment, installment toggle + repeatable installment rows.
2. Fee status badge computation, surfaced on Pipeline List rows.

**Exit criterion:** fee entry, installment math, and badge display verified against PRD §9's field table.

---

### Phase 5 — Final Verification & Registry (Stages 5–6)
1. Final Verification Queue screen (read-only preview reuse from Phase 2).
2. Second password gate (`FINAL_VERIFICATION_PASSWORD`) → status transition to `ADMITTED`, record lock.
3. `AdmittedStudent` snapshot write-out on transition.
4. Admitted Students Registry: searchable table view.

**Exit criterion:** a record can be walked end-to-end from Stage 1 through `ADMITTED` and appears correctly in the Registry, fully locked.

---

### Phase 6 — Dashboard Polish & Pipeline Views
1. Overview/Home funnel + quick stats.
2. Student Pipeline List: table + kanban toggle, filters (status/branch/category), progress indicators.
3. `ON_HOLD` / `REJECTED` exception paths (pending stakeholder confirmation, PRD §14.3) — implement once confirmed.

**Exit criterion:** full PRD §11.2 screen inventory complete and navigable.

---

### Phase 7 — Hardening
1. Security review: server-side password-gate enforcement audit, Aadhar/APAAR field encryption verification.
2. Performance pass: confirm preview/print render < 2s target (PRD §13); add caching/warm Playwright instances if needed.
3. Accessibility pass against Design doc §7.
4. Resolve remaining PRD §14 open questions with stakeholder (signatures, editing-after-ADMITTED workflow, multi-operator hand-off).

---

## 3. Dependencies & Sequencing Notes

- Phase 2 (print engine) depends only on Phase 1's schemas existing — it does **not** need the full wizard UI built, which is why it's sequenced early as a parallel/de-risking track.
- Phase 3 depends on Phase 1 (needs Form 2's checklist data) but is otherwise independent of Phase 2.
- Phase 5 depends on both Phase 2 (reuses preview) and Phase 3/4 (a record must be fee-recorded and printed first, per the status model).

## 4. Definition of Done (maps to PRD §15 Success Metrics)

- [ ] 100% of the 5 forms' fields represented and print-validated against physical originals
- [ ] Auto-fetch propagation verified with zero silent data loss across all 5 forms
- [ ] Document verification completion rate visible per admission cycle
- [ ] A front-desk operator completes one full admission end-to-end unassisted after a single walkthrough
