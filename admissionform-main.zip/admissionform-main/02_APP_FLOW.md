# App Flow
## Scholaris — Digital Admission Form Module

This document maps the full operator journey through the Admin Dashboard, stage by stage, screen by screen, matching the 6-stage workflow and 9-status model defined in the PRD (§4, §5).

---

## 0. Entry Point

**Dashboard Home** (logged-in admin, any role in v1 since Phase 1 ships one unified dashboard, §3):

- Pipeline funnel: count of records at each status.
- Quick stats: today's new admissions, pending verifications, pending fee balances.
- Primary CTA: **"+ New Admission"** → starts Stage 1.
- Secondary: **Student Pipeline List** (table/kanban, filterable by status/branch/category).

---

## 1. Stage 1 — Digital Form Filling (`DRAFT` → `FORMS_COMPLETE`)

**Entry:** "+ New Admission" → creates an `AdmissionRecord` with status `DRAFT`.

**Screen: 5-Form Wizard** (stepper: "Form 1 of 5" ... "Form 5 of 5")

```
Form 1: Application Form
   → auto-propagates shared fields (name, DOB, mobile, category, etc.)
Form 2: List of Documents (checklist ticks — drives Stage 2 later)
Form 3: Application for Eligibility (SPPU)
Form 4: Anti-Ragging Affidavit
Form 5: Library Membership Form
```

Per-form flow:
1. Operator fills the form. Fields already entered on a prior form in this record are **pre-filled silently** (subtle "auto-filled" indicator shown) per the Shared Field Auto-Fetch Map — operator may override locally without affecting the canonical source.
2. Autosave fires on field blur / debounce — an interrupted session can always resume from the last saved field.
3. **"Review this form" modal** appears at form end — clean read-only summary. Operator clicks **"Confirm & Continue"** or **"Back to Edit."**
4. Repeat for all 5 forms.

**Completion gate (end of Form 5):**
- System prompts a **modal password field: "Enter Admin Password to save this Admission Record."**
- Incorrect password → inline error, retry allowed, nothing is saved.
- Correct password → all 5 forms persist as one Admission Record; status → `FORMS_COMPLETE`; audit log entry written (actor, timestamp, action = "forms_saved").
- Wizard exits to the record's **Stage Overview** screen (see §7 below), now pointing at Stage 2.

---

## 2. Stage 2 — Document Upload & Verification (`FORMS_COMPLETE` → `DOCS_IN_PROGRESS` → `DOCS_VERIFIED`)

**Entry point:** Document Verification Workspace, auto-populated from Form 2's ticked checklist. Only rows marked "required" (ticked Yes) generate an upload slot; N/A rows stay hidden/disabled.

**Per-document slot flow:**
1. Slot state: `Not Uploaded`.
2. Operator chooses **Scan** (camera/scanner capture, auto-orientation correction) or **Drag-and-drop/Browse** (image/PDF).
3. On upload → slot state: `Uploaded (Pending Review)`. **System auto-check** runs immediately (file integrity, non-blank, correct format) and flags obvious issues inline.
4. Operator clicks **Preview** (inline viewer) → reviews the document.
5. Operator ticks **Received: Yes/No**, then clicks **Verified** (a distinct action from upload).
6. Slot state → `Verified` (or `Rejected – Reupload Required`, looping back to step 2).

**Stage completion:** once every required slot shows `Verified`, status auto-advances to `DOCS_VERIFIED`. Dashboard surfaces a progress indicator (e.g., "14/18 verified") at all times before this point (status `DOCS_IN_PROGRESS`).

---

## 3. Stage 3 — Fee Payment Status (`DOCS_VERIFIED` → `FEE_RECORDED`)

**Screen: Fee Entry Screen**

1. Operator enters Total Fee Amount, Amount Paid, Mode of Payment (Cash/UPI/Bank to Bank/RTGS/DD).
2. Remaining Balance auto-calculates.
3. If **Installment Plan** toggle is ON → a repeatable installment row appears: Installment #, Amount, Mode, Date, Remaining After Installment (auto-increment #, auto-calculated remaining).
4. Fee status badge (Unpaid / Partially Paid / Fully Paid) updates live and is visible on the student's pipeline row from this point on.
5. Save → status → `FEE_RECORDED`.

---

## 4. Stage 4 — Preview & Print (`FEE_RECORDED` → `READY_TO_PRINT` → `PRINTED`)

**Screen: Preview & Print Screen**

1. Full WYSIWYG render of all 5 forms exactly as they will print — headers, crest, table grids, checkbox glyphs, static legal text (Anti-Ragging clauses, Library Rules), office-use-only sections, all populated with candidate data.
2. Operator can click **"Edit Form N"** from anywhere in the preview → jumps back into the Stage 1 wizard for that form only, then returns to preview.
3. Once satisfied → **"Approve Preview"** → status → `READY_TO_PRINT`.
4. **"Print"** action → generates the paginated PDF bundle (all 5 forms, one document) → status → `PRINTED`; `PrintLog` entry written (printed_at, printed_by, version).

---

## 5. Stage 5 — Higher Authority Final Verification (`PRINTED` → `PENDING_FINAL_VERIFICATION` → `ADMITTED`)

**Screen: Final Verification Queue**

1. Record appears in the queue automatically after printing.
2. Higher authority (Principal/Registrar/HOD) opens the record → sees the **same read-only preview** used for printing, side-by-side (conceptually) with the physical printed copy they're holding.
3. Clicks **"Verified"** → modal prompts for **Verification Password**.
4. Correct password → status → `ADMITTED`; record **locks** (no further edits without an explicit unlock/audit action); `VerificationLog` entry written.
5. Incorrect password → retry, record stays in queue.

---

## 6. Stage 6 — Final Database (`ADMITTED`)

- Complete structured record (5 forms + document metadata + fee status + full verification audit trail) is written to the **Admitted Students Registry**.
- **Screen: Admitted Students Registry** — final searchable table (name, branch, category, admission year, fee status, etc.) — read-mostly, source for future modules (ID cards, attendance, academic records).

---

## 7. Cross-Cutting: Stage Overview / Record Detail Screen

Every Admission Record has a persistent detail view reachable from the Student Pipeline List, showing:
- Breadcrumb/stepper across all 6 stages (always visible, per §11.3 of PRD).
- Compact progress indicator: which of the 6 stages is complete.
- Direct links into whichever stage's screen is currently active for this record.

---

## 8. Exception Paths (recommended, pending confirmation — PRD §14.3)

- `ON_HOLD` — any stage, operator flags incomplete/ambiguous case; record pauses, reason logged, returns to its last active stage on resume.
- `REJECTED` — any stage, terminal state for ineligible candidates; record read-only, reason logged, does not proceed to Stage 6.

These two statuses branch off the main flow at any stage boundary shown above and are surfaced as filter options on the Student Pipeline List.

---

## 9. Flow Diagram (textual)

```
[Dashboard Home] → [+ New Admission]
        │
        ▼
[Stage 1: 5-Form Wizard] ──(password gate)──▶ FORMS_COMPLETE
        │
        ▼
[Stage 2: Document Verification Workspace] ──▶ DOCS_VERIFIED
        │
        ▼
[Stage 3: Fee Entry Screen] ──▶ FEE_RECORDED
        │
        ▼
[Stage 4: Preview & Print Screen] ──▶ READY_TO_PRINT ──▶ PRINTED
        │
        ▼
[Stage 5: Final Verification Queue] ──(password gate)──▶ ADMITTED
        │
        ▼
[Stage 6: Admitted Students Registry]

   (ON_HOLD / REJECTED branch off at any stage boundary)
```
