# Technical Specification
## Scholaris — Digital Admission Form Module (Phase 1: Admin Dashboard)

| | |
|---|---|
| **Derived from** | Scholaris_Admission_Module_PRD.md v1.0 |
| **Pilot tenant** | TSSM's Bhivarabai Sawant College of Engineering & Research, Narhe, Pune |
| **Scope** | Phase 1 — Admin Dashboard, 5-form wizard, document verification, fee tracking, print/preview, final verification, admitted registry |

---

## 1. Guiding Constraints from the PRD

These constraints drove every stack decision below:

- **Pixel-accurate, print-ready PDF output** on blank paper — Scholaris *is* the template (G5, §10). This is the single hardest technical requirement and rules out "good enough" HTML-to-PDF approaches.
- **Multi-tenant-ready architecture**, even though v1 hardcodes one college's forms (§13) — form schemas must be data-driven, not hardcoded UI.
- **Server-side enforced password gates** at two checkpoints — not cosmetic UI-only checks (§13).
- **Autosave** at every step, no data loss on interrupted sessions (§11.3).
- **Full audit trail** — every verification/password action logged with actor + timestamp (§13).
- **Sensitive PII** (Aadhar, APAAR/ABC ID) flagged for encryption at rest (§14.6).
- Front-desk laptop + tablet-scanning-station usage (§13) — no exotic client requirements.

---

## 2. Recommended Stack

| Layer | Choice | Why |
|---|---|---|
| **Frontend framework** | **Next.js 15 (App Router) + TypeScript** | Single codebase for dashboard UI + API routes; server components reduce client bundle for a form-heavy app; strong ecosystem for the PDF/print requirement below. |
| **UI library** | **Tailwind CSS + shadcn/ui (Radix primitives)** | Fully themeable design tokens (needed for the "warm/calm" design spec, §11.1 of PRD) without fighting a component library's defaults. Accessible out of the box (Radix). |
| **Forms & validation** | **React Hook Form + Zod** | Zod schemas double as the "data-driven form schema" the PRD requires for multi-tenancy readiness (§13) — the same schema validates client-side, server-side, and can generate the print template field list. |
| **State/data fetching** | **TanStack Query** + Next.js Server Actions | Server Actions handle mutations (save form, verify doc, password gate) with built-in progressive enhancement; TanStack Query handles autosave polling/optimistic UI. |
| **Database** | **PostgreSQL 16** | Relational integrity across 5 forms + shared fields + audit logs; JSONB columns available for form-specific field blobs without losing queryability on shared fields. |
| **ORM** | **Prisma** | Type-safe schema, migrations, and works cleanly with the data-driven form-definition approach (see §6, Schema doc). |
| **Auth / password gates** | **Auth.js (NextAuth) for session login** + a dedicated **`PasswordGate` server action** for the two in-flow checkpoints (post-5-forms save, final higher-authority verification) | PRD explicitly separates "who is logged in" from "the two specific re-authentication checkpoints" (§3, §11.3) — these are modeled as distinct concerns, not conflated. |
| **File storage** | **S3-compatible object storage** (AWS S3 / Cloudflare R2 / MinIO for self-host) | Document uploads (images/PDFs) need durable, addressable storage separate from the DB; R2/MinIO keep costs low for a single-college pilot. |
| **PDF / print generation** | **Playwright (headless Chromium) rendering a dedicated print-CSS HTML template** | This is the key decision (see §3 below). Print CSS + headless browser gives true pixel/layout fidelity to the original stationery, including tables, checkboxes, and static legal text — a requirement that template libraries like `pdf-lib` or `@react-pdf/renderer` handle far more awkwardly for complex, table-heavy government forms. |
| **Signature/photo capture** | Native `<input type="file">` + `getUserMedia` (camera capture) for scan intake | No dedicated e-signature vendor needed in v1 — PRD assumes wet-ink signing on print (§14.1). |
| **Background jobs** | **Inngest** or simple cron (pg-boss) for auto-verification checks on upload | Keeps "system auto-check" (§8) decoupled from the request/response cycle. |
| **Hosting** | Vercel (app) + managed Postgres (Neon/Supabase/RDS) + S3/R2 | Matches a lean, single-pilot-tenant deployment; migrates cleanly to self-host later if the college requires on-prem data residency (common ask for Indian education data). |
| **Testing** | Vitest (unit) + Playwright (e2e, doubles as the print-render engine) | Reusing Playwright for both e2e tests and PDF rendering reduces tooling surface area. |

---

## 3. Print/Preview Architecture (the hardest requirement)

Per §10 of the PRD: *"Print output must be byte-for-byte structurally faithful... since printing happens on blank paper, Scholaris is the template."*

**Approach:**
1. Each of the 5 forms has a **print-layout HTML/CSS template** (not the same component as the data-entry UI) built to match the physical form's exact geometry: same margins, table borders, checkbox glyphs (`☐`/`☑` or Unicode), underline-style fields, and verbatim static text (Anti-Ragging clauses, Library Rules, Annexure 'A' fee table).
2. Templates use `@page` CSS rules (size: A4, margins matching the original scanned forms) and `print-color-adjust: exact` to guarantee borders/backgrounds render.
3. **Preview mode** renders this exact template in an iframe/modal — WYSIWYG, re-editable via "back to form" navigation (§4.4).
4. **Print/export** pipes the same template through **Playwright's `page.pdf()`** server-side, producing one paginated PDF bundling all 5 forms in fixed order.
5. A **font/spacing validation checklist** (physical printout comparison) is a required manual QA gate before go-live (§10) — tracked as a task in the Tracker doc, not automatable away.

This single-template-source approach also satisfies the PRD's implicit rule: the preview a human sees pre-print must be *identical* to what a printer outputs — no separate "display" vs "print" template to drift apart.

---

## 4. Data-Driven Form Schema (multi-tenancy readiness)

Per §13: *"keep form schemas data-driven (not hardcoded UI) so a second college's differently-worded forms can be onboarded later."*

- Each of the 5 forms is defined as a **JSON/Zod schema** describing: field key, label, type, section, static/editable flag, and print-position metadata.
- The wizard UI, the shared-field auto-fetch map (§7 of PRD), and the print template all consume the **same schema** rather than three hand-maintained copies.
- v1 hardcodes exactly one schema set (this college's 5 forms); the schema *format* is generic enough that a second tenant's forms become new schema files, not a rewrite.

---

## 5. Security Notes

- Password gates (`FORMS_COMPLETE` save, `ADMITTED` final verification) are enforced in **server actions**, never trusted from client state.
- Aadhar No. and APAAR/ABC ID stored **encrypted at rest** (Postgres `pgcrypto` or application-level AES-256 envelope encryption); masked in UI by default, revealed only on explicit admin action (logged).
- All verification and password-gate events write to an append-only `VerificationLog` / `AuditLog` table (§12 of PRD) — never mutated, only inserted.
- File uploads scanned for correct MIME type server-side (not trusting client-reported type) before acceptance into Stage 2's auto-check pass.

---

## 6. Non-Functional Target Recap (from PRD §13)

| Requirement | Technical mechanism |
|---|---|
| Document preview/print render < 2s | Pre-rendered print HTML cached per record; Playwright render pooled/warmed, not cold-started per request |
| No silent field loss | Zod schema validation on every save; auto-fetch propagation logged, not silently overwritten |
| Touch-friendly tablet scanning | Tailwind responsive breakpoints + large tap targets on the Document Verification Workspace |
| Server-enforced password gates | Server Actions + session check, independent of client JS |
